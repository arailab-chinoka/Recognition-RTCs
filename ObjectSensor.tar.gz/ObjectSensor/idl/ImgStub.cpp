// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ImgStub.cpp 
 * @brief Img client stub wrapper code
 * @date Wed Aug 10 18:20:44 2011 
 *
 */

#include "ImgStub.h"

#if   defined ORB_IS_TAO
#  include "ImgC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "ImgSK.cc"
#  include "ImgDynSK.cc"
#elif defined ORB_IS_MICO
#  include "Img.cc"
#elif defined ORB_IS_ORBIT2
#  include "Img-cpp-stubs.cc"
#else
#  error "NO ORB defined"
#endif

// end of ImgStub.cpp
