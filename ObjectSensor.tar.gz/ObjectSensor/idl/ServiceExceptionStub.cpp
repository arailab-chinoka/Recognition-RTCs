// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ServiceExceptionStub.cpp 
 * @brief ServiceException client stub wrapper code
 * @date Thu Nov 05 00:41:03 2009 
 *
 */

#include "ServiceExceptionStub.h"

#if   defined ORB_IS_TAO
#  include "ServiceExceptionC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "ServiceExceptionSK.cc"
#  include "ServiceExceptionDynSK.cc"
#elif defined ORB_IS_MICO
#  include "ServiceException.cc"
#elif defined ORB_IS_ORBIT2
#  include "ServiceException-cpp-stubs.cc"
#else
#  error "NO ORB defined"
#endif

// end of ServiceExceptionStub.cpp
