// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ServiceExceptionSkel.cpp 
 * @brief ServiceException server skeleton wrapper
 * @date Thu Nov 05 00:41:03 2009 
 *
 */

#include "ServiceExceptionSkel.h"

#if defined ORB_IS_TAO
#  include "ServiceExceptionC.cpp"
#  include "ServiceExceptionS.cpp"
#elif defined ORB_IS_OMNIORB
#  include "ServiceExceptionSK.cc"
#  include "ServiceExceptionDynSK.cc"
#elif defined ORB_IS_MICO
#  include "ServiceException.cc"
#  include "ServiceException_skel.cc"
#elif defined ORB_IS_ORBIT2
#  include "ServiceException-cpp-stubs.cc"
#  include "ServiceException-cpp-skels.cc"
#else
#  error "NO ORB defined"
#endif

// end of ServiceExceptionSkel.cpp
