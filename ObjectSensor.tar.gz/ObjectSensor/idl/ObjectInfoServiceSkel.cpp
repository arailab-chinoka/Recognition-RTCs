// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ObjectInfoServiceSkel.cpp 
 * @brief ObjectInfoService server skeleton wrapper
 * @date Thu Nov 05 00:41:03 2009 
 *
 */

#include "ObjectInfoServiceSkel.h"

#if defined ORB_IS_TAO
#  include "ObjectInfoServiceC.cpp"
#  include "ObjectInfoServiceS.cpp"
#elif defined ORB_IS_OMNIORB
#  include "ObjectInfoServiceSK.cc"
#  include "ObjectInfoServiceDynSK.cc"
#elif defined ORB_IS_MICO
#  include "ObjectInfoService.cc"
#  include "ObjectInfoService_skel.cc"
#elif defined ORB_IS_ORBIT2
#  include "ObjectInfoService-cpp-stubs.cc"
#  include "ObjectInfoService-cpp-skels.cc"
#else
#  error "NO ORB defined"
#endif

// end of ObjectInfoServiceSkel.cpp
