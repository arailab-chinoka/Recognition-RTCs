// -*- C++ -*-
/*!
 * @file  ObjectSensor.h
 * @brief Object recognition using SIFT
 * @date  $Date$
 *
 * $Id$
 */

#ifndef OBJECTSENSOR_H
#define OBJECTSENSOR_H

#include <rtm/Manager.h>
#include <rtm/DataFlowComponentBase.h>
#include <rtm/CorbaPort.h>
#include <rtm/DataInPort.h>
#include <rtm/DataOutPort.h>
#include <rtm/idl/BasicDataTypeSkel.h>

// Service implementation headers
#include "AcceptModelSVC_impl.h"

// User's functions headers
// for vision
#include "SIFTPatternFinder.hpp"
#include "imgh_common.hpp"
#include "imgh_converter.hpp"
#include "cuda/cuda_image.h"
#include "cuda/cuda_sift.h"
// for util
#include "MultiCastEventListener.h"
#include "ImageViewer.h"
#include "TimeStampUtil_forRTC.h"
#include "ConnectionCheckUtil_forRTC.h"

#include "ImgStub.h"

using namespace ALTH;
using namespace ALTH::UTIL;
using namespace RTC;
using namespace Img;
/*!
 * @class ObjectSensor
 * @brief Object recognition using SIFT
 *
 */
class ObjectSensor
  : public RTC::DataFlowComponentBase,
    public EventListener<std::string>
{
 public:
  /*!
   * @brief constructor
   * @param manager Maneger Object
   */
  ObjectSensor(RTC::Manager* manager);

  /*!
   * @brief destructor
   */
  ~ObjectSensor();

  /**
   *
   * The initialize action (on CREATED->ALIVE transition)
   * formaer rtc_init_entry() 
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onInitialize();

  /***
   *
   * The finalize action (on ALIVE->END transition)
   * formaer rtc_exiting_entry()
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onFinalize();

  /***
   *
   * The startup action when ExecutionContext startup
   * former rtc_starting_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onStartup(RTC::UniqueId ec_id);

  /***
   *
   * The shutdown action when ExecutionContext stop
   * former rtc_stopping_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onShutdown(RTC::UniqueId ec_id);

  /***
   *
   * The activated action (Active state entry action)
   * former rtc_active_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onActivated(RTC::UniqueId ec_id);

  /***
   *
   * The deactivated action (Active state exit action)
   * former rtc_active_exit()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onDeactivated(RTC::UniqueId ec_id);

  /***
   *
   * The execution action that is invoked periodically
   * former rtc_active_do()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onExecute(RTC::UniqueId ec_id);

  /***
   *
   * The aborting action when main logic error occurred.
   * former rtc_aborting_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onAborting(RTC::UniqueId ec_id);

  /***
   *
   * The error action in ERROR state
   * former rtc_error_do()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
   virtual RTC::ReturnCode_t onError(RTC::UniqueId ec_id);

  /***
   *
   * The reset action that is invoked resetting
   * This is same but different the former rtc_init_entry()
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onReset(RTC::UniqueId ec_id);
  
  /***
   *
   * The state update action that is invoked after onExecute() action
   * no corresponding operation exists in OpenRTm-aist-0.2.0
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onStateUpdate(RTC::UniqueId ec_id);

  /***
   *
   * The action that is invoked when execution context's rate is changed
   * no corresponding operation exists in OpenRTm-aist-0.2.0
   *
   * @param ec_id target ExecutionContext Id
   *
   * @return RTC::ReturnCode_t
   * 
   * 
   */
  // virtual RTC::ReturnCode_t onRateChanged(RTC::UniqueId ec_id);


 protected:

  // Configuration variable declaration
  /*!
   * name of configuration file
   * - Name: CfgName
   * - DefaultValue: cfg/enon.cfg
   */
  std::string m_CfgName;

  /*!
   * object name in configuration file
   * - Name: ObjName
   * - DefaultVaule: crunky
   */
  std::string m_ObjName;

  /*!
   * flag for display / not display result image
   * - Name: display
   * - DefaultVaule: 0
   */
  std::string m_display;

 // InPort : single camera images
  // image buffer : single camera
  TimedCameraImage m_single_img;
  InPort<TimedCameraImage> m_single_imgIn;

  // DataOutPort declaration
  // object pose
  // OutPort : estimation result, for example pose and error
  TimedDoubleSeq m_obj_pose;
  OutPort<TimedDoubleSeq> m_obj_poseOut;
  // result image
  //TimedOctetSeq m_resimg_data;
  TimedCameraImage m_result_img;
  OutPort<TimedCameraImage> m_result_imgOut;

  // CORBA Port declaration
  // corba port for getting model
  RTC::CorbaPort m_ModelPort;
  
  // Service declaration
  AcceptModelServiceSVC_impl m_ModelAcceptor;
    
 private:
  SIFTPatternFinder _sift;  // sift pattern finder
  IMGH::Image _grayL, _grayR;	  // float images for CPU
  DevImage _cgrayL, _cgrayR;	  // float images for GPU (CUDA device)
  HstImage _csiftL, _csiftR;	  // extracted sift feature images for GPU
  IMGH::pixel_t _srcPixel_tL, _srcPixel_tR;   // pixel type of src image

  ImageViewer _iv; // image viewer
  //ALTH::UTIL::Mutex _model_sync;

  
  // log name
  std::string _logname;

  // read model 
  bool _onExeFlag;
  bool _ServiceFlag;
  bool _readModelFlag;

  // connection check
  int _modelC;

  // main function for object recognition
  bool findObject();

 public:
  // when "m_ModelAcceptor->setModel()" is called by other components,
  // this function is executed.
  void invokeEvent(const std::string &ev);
};


extern "C"
{
  void ObjectSensorInit(RTC::Manager* manager);
};

#endif // OBJECTSENSOR_H
