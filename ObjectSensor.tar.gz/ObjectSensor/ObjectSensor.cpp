// -*- C++ -*-
/*!
 * @file  ObjectSensor.cpp
 * @brief Object recognition using SIFT
 * @date $Date$
 *
 * $Id$
 */

#include "ObjectSensor.h"
//#include "ImageViewer.h"
//#ifdef WIN32
//#include <mmsystem.h>
//#pragma comment(lib, "winmm.lib")
//#endif

// Module specification
// <rtc-template block="module_spec">
static const char* objectsensor_spec[] =
  {
    "implementation_id", "ObjectSensor",
    "type_name",         "ObjectSensor",
    "description",       "Object recognition using SIFT",
    "version",           "0.4.0",
    "vendor",            "H.Takahashi, J.Choi, Osaka Univ.",
    "category",          "Recognition",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "1",
    "language",          "C++",
    "lang_type",         "compile",
    "exec_cxt.periodic.rate", "1.0",
    // Configuration variables
    "conf.default.CfgName", "cfg/sample.cfg",
    "conf.default.ObjName", "None",
    "conf.default.display", "on",	
    "conf.default.SIFT_nOctaves", "-1",
    "conf.default.SIFT_nLevels", "3",
    "conf.default.SIFT_Sigma", "1.6",
    "conf.default.SIFT_Ethreshold", "10",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
ObjectSensor::ObjectSensor(RTC::Manager* manager)
  // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_single_imgIn("SingleImage", m_single_img),
    m_obj_poseOut("ObjectPose", m_obj_pose),
    m_ModelPort("Model"),
    m_result_imgOut("ResultImg", m_result_img)

{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  registerInPort("SingleImage", m_single_imgIn);
  
  // Set OutPort buffer
  registerOutPort("ObjectPose", m_obj_poseOut);
  registerOutPort("ResultImage", m_result_imgOut);
  
  // Set service provider to Ports
  m_ModelPort.registerProvider("ModelAcceptor", "AcceptModelService", m_ModelAcceptor);
  
  // Set CORBA Service Ports
  registerPort(m_ModelPort);
}

/*!
 * @brief destructor
 */
ObjectSensor::~ObjectSensor()
{
}



RTC::ReturnCode_t ObjectSensor::onInitialize()
{
  // Bind variables and configuration variable
  bindParameter("CfgName", m_CfgName, "cfg/sample.cfg"); //configuration file's name
  bindParameter("ObjName", m_ObjName, "None"); //object ID for searching
  bindParameter("display", m_display, "on"); //display result or not

  _sift.verbose=true;

  // observe service port's funtion
  m_ModelAcceptor.addEventListener(this);

  std::cout << "### Object Sensor Component ###" << std::endl;

  std::cout << "setting initial SIFT parameter" << std::endl;
  // set parameter
  _sift.use_gpu = true;
  bindParameter("SIFT_nOctaves", _sift.sift_nOctaves, "-1"); // number of octaves (if positive.  0:auto(default), -1:auto with upsampling)
  bindParameter("SIFT_nLevels", _sift.sift_nLevels, "3"); // number of blurring levels in each octave [3]
  bindParameter("SIFT_Sigma", _sift.sift_sigma, "1.6"); // size of the initial Gaussian filter [GPU:1.6 CPU:0.5]
  bindParameter("SIFT_Ethreshold", _sift.sift_ethreshold, "10"); // rejection threshold for keypoints on edge [10.0]

  // print initial information
  std::cout << "  -SIFT_nOctaves : " << _sift.sift_nOctaves << std::endl;
  std::cout << "  -SIFT_nLevels : " << _sift.sift_nLevels << std::endl;
  std::cout << "  -SIFT_Sigma : " << _sift.sift_sigma << std::endl;
  std::cout << "  -SIFT_Ethreshold : " << _sift.sift_ethreshold << std::endl;
	
  //----------------- this line will be deleted soon. -------------------
  //_sift.loadCameraParameters(const_cast<char*>(m_CfgName.c_str()) );
  //---------------------------------------------------------------------

  // allocate memory buffer for pose
  m_obj_pose.data.length(12);
  for(int i=0; i<12; ++i) m_obj_pose.data[i]=0.0;

  // add listener to model acceptor port
  m_ModelAcceptor.addEventListener(this);
  m_ModelAcceptor.lockSetModel();
	
  // initialize log file
  ::UTIL::Timer time;
  _logname.resize(18);
  time.getDateTimeString(const_cast<char*>(_logname.c_str()));
  _logname+="_log.txt";
  FILE *fp;
  if((fp = fopen(_logname.c_str(), "a+")) == 0 ){
    ;
  } else {
    fprintf( fp, "object %s : transfer[sec] downloadform[sec] SIFT extruction[sec] Match sift pattern[sec] Pose estimation[sec] total [sec] : Rotation[0] Rotation[1] Rotation[2] Rotation[3] Rotation[4] Rotation[5] Rotation[6] Rotation[7] Rotation[8] translation[0] translation[1] translation[2]\n", m_ObjName.c_str());
    fclose(fp);
  }
	
  return RTC::RTC_OK;
}



RTC::ReturnCode_t ObjectSensor::onFinalize()
{
  return RTC::RTC_OK;
}


/*
  RTC::ReturnCode_t ObjectSensor::onStartup(RTC::UniqueId ec_id)
  {
  return RTC::RTC_OK;
  }
*/

/*
  RTC::ReturnCode_t ObjectSensor::onShutdown(RTC::UniqueId ec_id)
  {
  return RTC::RTC_OK;
  }
*/


RTC::ReturnCode_t ObjectSensor::onActivated(RTC::UniqueId ec_id)
{
  // while ( !m_single_imgIn.isNew() ){
  //   coil::sleep(1);
  //   std::cout<< "Waiting for recieving Image buffer" << std::endl;
  // }

  // std::cout << "Image read finish " << std::endl;

  // check connection of service port
  ALTH::UTIL::CheckPortConnection cpc;
  cpc.addConnectorPropertyName("port.AcceptModelService.ModelAcceptor");
  _modelC = cpc(m_ModelPort);

  if( _modelC > 0 ){  // Port is connected 
    std::cout << "ServicePort:Model  is connected " << std::endl;
    m_ObjName = "None";
    
  }else { // Port is not connected 
    std::cout << "ServicePort:Model  is not connected " << std::endl; 
  }

  // load reference image and it's pose
  if(m_ObjName == "None"){
    std::cout << "Model is None, so model image was not loaded" << std::endl;
    m_ModelAcceptor.unlockSetModel();
    _readModelFlag = true;
    return RTC::RTC_OK;
  }

  std::cout << "loading reference pattern[" << m_ObjName << "] from file" << std::endl;
  if(!_sift.loadReferencePattern(const_cast<char*>(m_CfgName.c_str()), const_cast<char*>(m_ObjName.c_str()))){
    std::cout << "...failed : reference image doesn't exist" << std::endl;
    return RTC::RTC_ERROR;
  }else{
    std::cout << "...done" << std::endl;
  }
  _readModelFlag = false;

  m_ModelAcceptor.unlockSetModel();
	
  // print current setting information
  std::cout << "\nthe setting of sorce image format is as follows."
	    << "\n  -pixel type: " << getLabel((ALTH::pixel_t)_srcPixel_tL)
	    << "\n  -resolution: " << _grayL.w << "x" << _grayL.h
	    << "\nthe setting of camera parameter is as follows." << std::endl;
  _sift.camera.printInfo();

  std::cout <<  "Number of sift feature of reference image :  " << _sift.refer.fimg.h << std::endl;

  return RTC::RTC_OK;
}



RTC::ReturnCode_t ObjectSensor::onDeactivated(RTC::UniqueId ec_id)
{
  _iv.closeWindow();
  m_ModelAcceptor.lockSetModel();

  return RTC::RTC_OK;
}



RTC::ReturnCode_t ObjectSensor::onExecute(RTC::UniqueId ec_id)
{
  // if object key is 'None', do nothing.
  if(m_ObjName == "None"){return RTC::RTC_OK;}

  // model port is not connected, find target object 
  if( _modelC < 0 ){
    std::cout << "finding object in onExecute : " << findObject() << std::endl;
  }

  // model port is connected and set new model 
  //if( ( _modelC>0 && _ServiceFlag ) ){ return RTC::RTC_OK;}

  // // when model port is not connected / model port is called, findObj() function is used.
  // if(!( (_modelC<0) || (_modelC>0 && _ServiceFlag) )){ return RTC::RTC_OK;}

  // // set new model
  // // _ServiceFlag == true : invokeEvent is called.
  // // _readModelFlag == true : read model
  // if(_readModelFlag && _ServiceFlag){
  //   std::cout << "set new model [" << m_ObjName << "] " << std::ends;
  //   if(!_sift.loadReferencePattern(const_cast<char*>(m_CfgName.c_str()), const_cast<char*>(m_ObjName.c_str()))){
  //     std::cout << "... failed." << std::endl;
  //     m_ObjName = "None";
  //   }
  //   _readModelFlag = false; // model is loaded
  // }

  // set new model
  if(_readModelFlag){
    std::cout << "set new model [" << m_ObjName << "] " << std::ends;
    if(!_sift.loadReferencePattern(const_cast<char*>(m_CfgName.c_str()), const_cast<char*>(m_ObjName.c_str()))){
      std::cout << "... failed." << std::endl;
      m_ObjName = "None";
    }
    _readModelFlag = false; // model is loaded
  }
  // find target object 
  else{
    _onExeFlag = true;
    std::cout << "finding object in onExecute : " << findObject() << std::endl;
    _onExeFlag = false;
  }

  // // find target object
  // if( ( !_onExeFlag && !_ServiceFlag) ){
  //   _onExeFlag = true;
  //   std::cout << "finding object in onExecute : " << findObject() << std::endl;
  //   _onExeFlag = false;
  // }

  return RTC::RTC_OK;
}


/*
  RTC::ReturnCode_t ObjectSensor::onAborting(RTC::UniqueId ec_id)
  {
  return RTC::RTC_OK;
  }
*/


RTC::ReturnCode_t ObjectSensor::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}


/*
  RTC::ReturnCode_t ObjectSensor::onReset(RTC::UniqueId ec_id)
  {
  return RTC::RTC_OK;
  }
*/

/*
  RTC::ReturnCode_t ObjectSensor::onStateUpdate(RTC::UniqueId ec_id)
  {
  return RTC::RTC_OK;
  }
*/

/*
  RTC::ReturnCode_t ObjectSensor::onRateChanged(RTC::UniqueId ec_id)
  {
  return RTC::RTC_OK;
  }
*/

bool ObjectSensor::findObject(){

  // variable number declaration
  double time_log[6]={0.0};              // time log data : read, conversion, extract SIFT, pose estimation
  //	int time(0);                           // time for log
  ::UTIL::Timer timer;                     // timer for log
  static RTC::Time pTm;                  // previous time
  RTC::Time cTm;                         // current time
  bool found_2d(false), found_3d(false); // flag: success/failed of detection and pose estimation
	
  // start timer
  timer.start();
	
  //single image
  if( m_single_imgIn.isNew() ){
    while( !m_single_imgIn.isEmpty() ) m_single_imgIn.read();

    // camera parameters
    double f[2], c[2], a, d[5];

    // read single image
    m_single_imgIn.read();

    // read image size
    _grayL.w = m_single_img.data.image.width;
    _grayL.h = m_single_img.data.image.height;
    if( m_single_img.data.image.format == CF_GRAY ) _grayL.type = IMGH::PIXEL_GRAY,_srcPixel_tL = IMGH::PIXEL_GRAY;
    else if( m_single_img.data.image.format == CF_RGB ) _grayL.type = IMGH::PIXEL_RGB,_srcPixel_tL = IMGH::PIXEL_RGB;
    else  _grayL.type = IMGH::PIXEL_UNKNOWN,_srcPixel_tL = IMGH::PIXEL_UNKNOWN;
	
    _cgrayL.setImage(_grayL.w, _grayL.h);

    // read camera paramters
    f[0] = m_single_img.data.intrinsic.matrix_element[0];
    f[1] = m_single_img.data.intrinsic.matrix_element[2];
    c[0] = m_single_img.data.intrinsic.matrix_element[3];
    c[1] = m_single_img.data.intrinsic.matrix_element[4];
    a    = m_single_img.data.intrinsic.matrix_element[1]; 

    for( int i=0;i<5;i++)
      d[i]=m_single_img.data.intrinsic.distortion_coefficient[i];

    // std::cout << "camera parameters" << std::endl;
    // std::cout << "intrinsic : " ; for(int i=0; i<5; ++i){ std::cout << m_single_img.data.intrinsic.matrix_element[i] << " " ;} std::cout << std::endl;
    // std::cout << "distortion : " ;for(int i=0; i<5; ++i){ std::cout << d[i] << " " ;} std::cout << std::endl;

    // set camera parameters
    //_sift.setLCInParam(_grayL.w, _grayL.h, f, a, c, d);

    _sift.camera.setIntrinsic( _grayL.w, _grayL.h, f, a, c, d);
    _sift.camera.updatePmatUsingParam();
		
    // set result image size
    m_result_img.data.image.width= _grayL.w;
    m_result_img.data.image.height = _grayL.h;
    m_result_img.data.image.format = CF_RGB;
    // allocate buffer for result image
    m_result_img.data.image.raw_data.length( (_grayL.w+_grayR.w)*_grayL.h*3);



    //std::cout << "single image is read" << std::endl;
		
    _grayL.type = _srcPixel_tL;
	
    // // check trans port time
    // cTm = getCurrentTimeStamp();
    // RTC::Time eTm = cTm - m_single_img.tm;
    // time_log[0] = toDouble(eTm);
		
    // check time of reading data
    time_log[0] = timer.checkTime();

    // check elapsed time
    //eTm = cTm - pTm;

    // set previous time
    //pTm = cTm;
    //if(toDouble(eTm) > 1.0){
    // time is out
    //	std::cout << "current image is time out." << std::endl;
    //	return  false;
    //}

    // convert images format to float gray image
    if (_grayL.type != IMGH::PIXEL_FLOAT){
      //std::cout << "converting image type" << std::ends;
      IMGH::ImageConverter conv;

      IMGH::Image imgL( _grayL.w, _grayL.h, _srcPixel_tL, (void*)&(m_single_img.data.image.raw_data[0]) );
      conv.convertImage( &imgL, &_grayL, IMGH::PIXEL_FLOAT );
			
      //std::cout << " ... done" << std::endl;
    }

    // check time of conversion
    time_log[1] = timer.checkTime();

    //std::cout << "set gpu memory" << std::endl;
    // load image from host memory to GPU memory
    _cgrayL.downloadFrom( (float*)_grayL.data );
    time_log[2] = timer.checkTime();
		
    // extract sift featrues using GPU
    bool retL = cuda_sift_extract( &_cgrayL, &_csiftL, _sift.sift_nOctaves, _sift.sift_nLevels, _sift.sift_sigma, _sift.sift_ethreshold, NULL, false );
	
    //std::cout << "finish to extrat sift feature " << std::endl;
    std::cout << "Number of scene feature = " << _sift.scene.fimg.h << std::endl;

    // check time of SIFT extruction
    time_log[3] = timer.checkTime();
    //if (!retL || !retR){
    if (!retL ){
      std::cout << "error : sift extract process is failed" << std::endl;
    }
    else {
      // Now sift features are saved in 'csiftL' and 'csiftR', as float-valued images (width:140, height:NumberOfFeatures)
		
      _sift.setupInputImageWithFloatBuffer( _grayL.w, _grayL.h, (float *)_grayL.data );
      _sift.setupSIFTFeaturesWithBuffer( _csiftL.h, (SIFTFeature*)_csiftL.data );

      // find the reference pattern using 'B'oth ('L'eft and 'R'ight) pattern finders
      double Rco[9]={0.0}, Tco[3]={0.0};
			
      std::cout << "start to match sift feature" << std::endl;
      found_2d = _sift.findSIFTPattern();
      time_log[4] = timer.checkTime();
      if( found_2d ) {
	std::cout << "start to get Result 3D pose" << std::endl;
	found_3d = _sift.getResult3DPose(Rco,Tco);
      }

      // check time of pose estimation
      time_log[5] = timer.checkTime();

      // display result
      if (m_display=="on") {
	// get result image for display
	IMGH::Image resimg;
				
	_sift.getResultImage( &resimg, false, true, true );
	// copy buffer
	resimg.copyToBuffer((unsigned char*)&m_result_img.data.image.raw_data[0]);
	
	//set time stamp
	m_result_img.tm = m_single_img.tm;
	
	// send img
	m_result_imgOut.write();
	   		
	// show result image
	_iv.setWindowSize(_grayL.w, _grayL.h);
	_iv.setImagePixelType(PIXEL_RGB);
	_iv.openWindow();
	_iv.waitKeyDisplay( resimg.data, 10);
      }
      else if (m_display == "off") {
	_iv.closeWindow();
      }
      std::cout <<"Number of SIFT Feature Matching : "<< _sift.match.matched_count << std::endl;
      // push estimated pose from OutPort
      if(found_2d && found_3d){
	// push estimated pose
	memcpy(&(m_obj_pose.data[0]),&Rco[0],3*sizeof(double));
	memcpy(&(m_obj_pose.data[4]),&Rco[3],3*sizeof(double));
	memcpy(&(m_obj_pose.data[8]),&Rco[6],3*sizeof(double));
	for(int i=0;i<3;i++){
	  m_obj_pose.data[3+4*i] = Tco[i];
	}
	//m_obj_pose.data[12] = (double)found_2d;
	//m_obj_pose.data[13] = (double)found_3d;
	m_obj_pose.tm = m_single_img.tm;
	std::cout << m_ObjName << " is found." << std::endl;
	std::cout << "time stamp : " << m_obj_pose.tm.sec << "[sec] " << m_obj_pose.tm.nsec << "[nsec]" << std::endl;
	std::cout << "pose is as follows." << std::endl;
	G3M_XFORM_PRINTF(Rco, Tco);

	if(!m_obj_poseOut.write()){
	  std::cout << "error: pose is not sent!" << std::endl;
	}

      }else{
	std::cout << m_ObjName << " is not found." << std::endl;
      }
    }
  } //end of "if(m_single_imgIn.isNew())": new image is pushed? 

  timer.stop();

  // write time's log
  FILE *fp;
  if((fp = fopen(_logname.c_str(), "a+")) == 0 ){
    ;
  } else {
    if(found_2d && found_3d){
      fprintf( fp, "%s : ", m_ObjName.c_str());
      double total_time=0;
      for(int i=0; i<6; ++i){
	fprintf( fp, "%.6f ", time_log[i]);
	total_time+= time_log[i];
      }
      fprintf(fp, "%.6f  : ", total_time);
      for(int i=0; i<12; ++i) fprintf( fp, "%.6lf ", m_obj_pose.data[i]);
      fprintf(fp, "\n");
      fclose(fp);

      return true;
    }
    fclose(fp);
  }

  return false;
}


// when "m_ModelAcceptor->setModel()" is called by other components,
// this function is executed.
void ObjectSensor::invokeEvent(const std::string &ev){
  std::cout << "invokeEvent is called." << std::endl;

  // if object ID is current ID, the object model is not updated.
  if(ev == m_ObjName){
    std::cout << "Current model ID is same, so model was not changed" << std::endl;
    return;
  }

  // set model ID  
  m_ObjName = ev;

  // if object ID is "None", the object model is not updated.
  if(ev == "None" ){
    std::cout << "Set model ID to None" << std::endl;
    return;
  }
    
  // _ServiceFlag = true; 

  std::cout << "Waiting for finishing to execute function : findObject()"  << std::endl;
  while(_onExeFlag){
    coil::usleep(1000);
  } 
  _readModelFlag =true;
  
  std::cout << "Waiting for finishing to read model image"  << std::endl;
  while(_readModelFlag){
    coil::usleep(1000);
  } 
  std::cout << "Change model to " << ev << std::endl;

  //_ServiceFlag = false;
  
  // while(1){
  //   if(!_onExeFlag){ // findObj() function is not
  //     std::cout << "findObj() is not used in onExecute." << std::endl;
  //     if(m_ObjName != ev){
  // 	m_ObjName = ev;
  // 	_readModelFlag = true; // onExecute function can read model.

  // 	while(1){
  // 	  if(!_readModelFlag){ // _readModelFlag :false.//model is loaded.
  // 	    break;
  // 	  }
  // 	}

  //     }
  //     _onExeFlag=true;    // 
  //     break;
  //   }else{ // findObj() is used in onExecute
  //     std::cout << "findObj() is used in onExecute." << std::endl;
  //     if(m_ObjName == "None"){
  // 	m_ObjName = ev;
  // 	_readModelFlag = true;

  // 	while(1){
  // 	  if(!_readModelFlag){
  // 	    break;
  // 	  }
  // 	}
  // 	_onExeFlag = true;   // unlock findObj()
  // 	break;
  //     }
  //   }
  //   coil::usleep(100);
  // }

  // while(1){
  //   if(!_onExeFlag){
  //     _ServiceFlag=false;
  //     break;
  //   }
  //   coil::usleep(100);
  // }
}

extern "C"
{
 
  void ObjectSensorInit(RTC::Manager* manager)
  {
    coil::Properties profile(objectsensor_spec);
    manager->registerFactory(profile,
                             RTC::Create<ObjectSensor>,
                             RTC::Delete<ObjectSensor>);
  }
  
};


