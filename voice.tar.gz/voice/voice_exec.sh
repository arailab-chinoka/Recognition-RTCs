#!/bin/sh

echo "sh "$0" {exec|exit|con|act|deact|dis|del}"

exec_with_echo()
{
    echo $1
    $1
}

case "$1" in 
    "exec")
	
	gnome-terminal -t juliusrtc -e 'juliusrtc rhdemo.grxml'
	# gnome-terminal -t seat -e 'seat snack.seatml'
	gnome-terminal -t SEAT2 -e 'python SEAT2.py rhdemo.seatml'
	COM="gnome-terminal"
	COM1="$COM --tab -t pulseaudioinput -e pulseaudioinput"
	COM1="$COM1 --tab -t pulseaudiooutput -e pulseaudiooutput"
	COM1="$COM1 --tab -t openjtalkrtc -e openjtalkrtc"
	exec_with_echo "$COM1 &"
esac

case "$1" in
    "exit")
	killall pulseaudioinput
	killall pulseaudiooutput
	killall openjtalkrtc
	killall juliusrtc
	killall seat
	killall python
esac

case "$1" in
    "con")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_connect_without_danger.sh con"
        echo ""
        ;;
    "act")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_activate_without_danger.sh"
        echo ""
        ;;
    "deact")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_deactivate.sh"
        echo ""
        ;;
    "dis")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_connect_without_danger.sh dis"
        echo ""
        ;;
    "del")
        . shell/setenv.sh
        exec_with_echo "sh shell/all_delete.sh"
        echo ""
        ;;
esac