# rtshell environment variable
#NS2809="192.168.11.3"
export NS2809="localhost"
export NS9876="localhost:9876"
export RTCTREE_NAMESERVERS="$NS2809;$NS9876"

# Initialization of rtcwd
if [ -f /usr/local/share/rtshell/shell_support ]; then
    # for rtshell-3.0
    . /usr/local/share/rtshell/shell_support
elif [ -f /usr/local/bin/rtcwd ]; then
    # for rtcshell-2.0
    . /usr/local/bin/rtcwd
fi

# ネームサーバが2個以上あるときの対応
#rtcwd /$RTCTREE_NAMESERVERS
