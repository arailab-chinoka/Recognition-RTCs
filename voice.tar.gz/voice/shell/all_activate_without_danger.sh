#!/bin/sh
#********************************************************
#  all component activate script
#********************************************************

# set environment variable
rtact $NS2809/PulseAudioInput0.rtc
rtact $NS2809/PulseAudioOutput0.rtc
rtact $NS2809/JuliusRTC0.rtc
rtact $NS2809/OpenJTalkRTC0.rtc
rtact $NS2809/SEAT0.rtc

echo "********************************************************"
echo "全コンポーネントの起動が終了しました"
echo "********************************************************"
