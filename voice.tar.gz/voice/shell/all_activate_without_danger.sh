#!/bin/sh
#********************************************************
#  Reference hardware object picking demonstration 
#  all component activate script
#********************************************************

# set environment variable
rtact $NS2809/PulseAudioInput0.rtc
rtact $NS2809/PulseAudioOutput0.rtc
rtact $NS2809/JuliusRTC0.rtc
rtact $NS2809/OpenJTalkRTC0.rtc
rtact $NS2809/SEAT20.rtc

echo "********************************************************"
echo "********************************************************"
echo "全コンポーネントの起動が終了しました"
echo "********************************************************"
echo "********************************************************"
