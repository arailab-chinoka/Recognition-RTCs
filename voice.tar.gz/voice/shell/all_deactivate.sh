#!/bin/sh
#********************************************************
#component deactivate script
#********************************************************

# set environment variable
#source setenv.sh


echo "========================================================"
echo "コンポーネントの動作を停止します"
echo "========================================================"

rtdeact $NS2809/PulseAudioInput0.rtc
rtdeact $NS2809/PulseAudioOutput0.rtc
rtdeact $NS2809/JuliusRTC0.rtc
rtdeact $NS2809/OpenJTalkRTC0.rtc
rtdeact $NS2809/SEAT0.rtc

echo "********************************************************"
echo "コンポーネントを停止しました"
echo "********************************************************"
