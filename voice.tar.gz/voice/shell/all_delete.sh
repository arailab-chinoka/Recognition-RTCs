#!/bin/sh
#********************************************************
#IREX demonstration all component delete script
#********************************************************

# set environment variable
#source setenv.sh

rtdel $NS2809/RefHardRh20.rtc
rtdel $NS2809/Odometry0.rtc

#rtdel $NS2809/RH2ArmControl0.rtc
rtdel $NS2809/MnpData_Hub0.rtc
rtdel $NS2809/RMRC0.rtc
rtdel $NS2809/tool_ctrl0.rtc
rtdel $NS2809/tool_mixer0.rtc
rtdel $NS2809/OSAKA/RHBaseControl0.rtc
rtdel $NS2809/OSAKA/RH2ArmMove0.rtc

# rtdel $NS2809/Rh2ArmControl0.rtc
# rtdel $NS2809/OSAKA/FireWebCamera0.rtc
# rtdel $NS2809/OSAKA/FireWireCamera0.rtc
rtdel $NS2809/OSAKA/ObjectSensor0.rtc
rtdel $NS2809/OSAKA/Viewer0.rtc
rtdel $NS2809/OSAKA/ObjectInfoManager0.rtc
rtdel $NS2809/OSAKA/TransformMatrix0.rtc
rtdel $NS2809/OSAKA/ApproachMotion0.rtc
rtdel $NS2809/OSAKA/PickMotion0.rtc
rtdel $NS2809/OSAKA/ComponentManager0.rtc
