#!/bin/sh
#
#********************************************************
# component connect script
#********************************************************

# set environment variable
#. setenv.sh

COM="rtcon"
case "$1" in
    "con")
        COM="rtcon"
        ;;
    "dis")
        COM="rtdis"
        ;;
esac

echo "==============================================================================="
echo "Component Connections of Voice Recognition"
echo "==============================================================================="
$COM $NS2809/PulseAudioInput0.rtc:AudioDataOut \
     $NS2809/JuliusRTC0.rtc:data \

$COM $NS2809/SEAT0.rtc:speechin \
     $NS2809/JuliusRTC0.rtc:result \

$COM $NS2809/SEAT0.rtc:speechout \
     $NS2809/OpenJTalkRTC0.rtc:text \

$COM $NS2809/PulseAudioOutput0.rtc:AudioDataIn \
     $NS2809/OpenJTalkRTC0.rtc:result \
     
echo "*******************************************************************************"
echo "*******************************************************************************"
echo "Component Connection OK!!"
echo "*******************************************************************************"
echo "*******************************************************************************"
