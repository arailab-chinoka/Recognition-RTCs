// -*- C++ -*-
/*!
 * @file  ObjectInfoManager.cpp
 * @brief mangement of object pose and position  :Robot Information management server
 * @date $Date$
 *
 * $Id$
 */

#include "ObjectInfoManager.h"

// Module specification
// <rtc-template block="module_spec">
static const char* objectinfomanager_spec[] =
  {
    "implementation_id", "ObjectInfoManager",
    "type_name",         "ObjectInfoManager",
    "description",       "mangement of object pose and position  :Robot Information management server",
    "version",           "1.0.0",
    "vendor",            "Kyohei Iwane Osaka Univ.",
    "category",          "RIMS",
    "activity_type",     "PERIODIC",
    "kind",              "DataFlowComponent",
    "max_instance",      "0",
    "language",          "C++",
    "lang_type",         "compile",
    ""
  };
// </rtc-template>

/*!
 * @brief constructor
 * @param manager Maneger Object
 */
ObjectInfoManager::ObjectInfoManager(RTC::Manager* manager)
    // <rtc-template block="initializer">
  : RTC::DataFlowComponentBase(manager),
    m_ObjectPoseIn("ObjectPose", m_ObjectPose),
    m_TransMatIn("TransMat", m_TransMat),
    m_GetInfoPort("GetInfo"),
    m_ModelPort("Model"),
    _transMat(TC::TRANS_HOMOGENEOUS, TC::TRANS_HOMOGENEOUS),
    _cObjKey("something")

    // </rtc-template>
{
}

/*!
 * @brief destructor
 */
ObjectInfoManager::~ObjectInfoManager()
{
}



RTC::ReturnCode_t ObjectInfoManager::onInitialize()
{
  // Registration: InPort/OutPort/Service
  // <rtc-template block="registration">
  // Set InPort buffers
  addInPort("ObjectPose", m_ObjectPoseIn);
  addInPort("TransMat", m_TransMatIn);
  
  // Set OutPort buffer
  
  // Set service provider to Ports
  m_GetInfoPort.registerProvider("RIMSService", "RIMSService", m_RIMSService);
  
  // Set service consumers to Ports
  m_ModelPort.registerConsumer("ModelAcceptor", "AcceptModelService", m_ModelAcceptor);
  
  // Set CORBA Service Ports
  addPort(m_GetInfoPort);
  addPort(m_ModelPort);
  
  // </rtc-template>

  // set default transform format
  string inTransType =  "TRANS_HOMOGENEOUS";
  string outTransType = "TRANS_HOMOGENEOUS";
  _transMat.setTransType(inTransType.c_str(), outTransType.c_str());

  // set observer to observe the object information
  m_RIMSService.addEventListener(this);
  
  // lock service port
  m_RIMSService.lockObjInfoService();
  
  // allocate buffer
  m_TransMat.data.length(12);
  
  // initialize log file
  ::UTIL::Timer time;
  _logname.resize(18);
  time.getDateTimeString(const_cast<char*>(_logname.c_str()));
  _logname+="_log.txt";
  //_logname = "log/" + _logname;
  FILE *fp;
  if((fp = fopen(_logname.c_str(), "a+")) == 0 ){
    ;
  } else {
    fprintf( fp, "object : timestamp[sec] [usec] : Rotation[0] Rotation[1] Rotation[2] Rotation[3] Rotation[4] Rotation[5] Rotation[6] Rotation[7] Rotation[8] translation[0] translation[1] translation[2]\n");
    fclose(fp);
  }



  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t ObjectInfoManager::onFinalize()
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t ObjectInfoManager::onStartup(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t ObjectInfoManager::onShutdown(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


RTC::ReturnCode_t ObjectInfoManager::onActivated(RTC::UniqueId ec_id)
{
  _exec_flag = false, _service_flag = false;
  
  // check connection of service port
  ALTH::UTIL::CheckPortConnection cpc;
  cpc.addConnectorPropertyName("port.AcceptModelService.ModelAcceptor");
  _modelPortC = cpc(m_ModelPort);

  // initialize
  for(int i=0; i<12; ++i){_pretransMat[i] = 0.0;}

  // set time out value
  //m_ObjInfoService.setTimeOutValue(m_timeout);

  // check current time
  //_preTm = ALTH::UTIL::getCurrentTimeStamp();

  //----- initialize translate matrix for debug --------
  /*double R[9]={0.0,  0.0, 1.0,
    -1.0,  0.0, 0.0,
    0.0, -1.0, 0.0};
    double T[3]={0.0, 0.0, 0.0};
    _transMat.setTransMat(R, T);*/
  //----------------------------------------------------

  // unlock service
  m_RIMSService.unlockObjInfoService();


  return RTC::RTC_OK;
}


RTC::ReturnCode_t ObjectInfoManager::onDeactivated(RTC::UniqueId ec_id)
{
   // lock servicce port function
  m_RIMSService.lockObjInfoService();
  //m_ObjInfoService.closeDisplayWindow();
  _objManager.deleteAllObjectInfo();
  // _objManager.deleteObjectInfo(_cObjKey);

 return RTC::RTC_OK;
}


RTC::ReturnCode_t ObjectInfoManager::onExecute(RTC::UniqueId ec_id)
{
  // read Object Pose
  if( m_ObjectPoseIn.isNew() ){
    //_exec_flag = true;

    // RTC::Time startTime;
    // startTime = ALTH::UTIL::getCurrentTimeStamp();

    while( !m_ObjectPoseIn.isEmpty() ) m_ObjectPoseIn.read();
    
    // transform matrix is sent
    if (m_TransMatIn.isNew()){
      while( !m_TransMatIn.isEmpty() )  m_TransMatIn.read();
      
      // set transform matrix 
      _transMat.setTransMat((double*)&m_TransMat.data[0]);
    }
    
    // initialize 
    RTC::Time ctm;
    double objPose[12];
    for( int i=0 ; i< 12; ++i) objPose[i]=0;
    
    // calculate Transform Matrix 
    _transMat.calculateTransformMatrix( &m_ObjectPose.data[0],  objPose);
    
    // set Object Information
    _obj.setTimeStamp( m_ObjectPose.tm.sec, m_ObjectPose.tm.nsec/1000 );
    _obj.setInformation( _cObjKey, objPose);
    
    //////////////////////////////////////////////
    // register object info to manager
    //m_ObjInfoService.registerObjectInfo(_obj);
    // 要変更
    ///////////////////////////////////////////////

    _objManager.registerObjectInfo(_obj);
    
    // print info
    // std::cout << _cObjKey << " is registered." << std::endl;
    _obj.printAllInfomation();

    // wirte info into log file
    FILE *fp;
    if((fp = fopen(_logname.c_str(), "a+")) == 0 ){}
    else{
      std::cout << "writing log file" << std::ends;
      fprintf( fp, "--------------------------------------------------------------------------------------------\n");
      fprintf( fp, "%s, ", _cObjKey.c_str());
      fprintf( fp, "%.6d, %.6d, ", _obj.getTimeStamp().sec, _obj.getTimeStamp().usec);
      double R[9], T[3]; _obj.getPose(R, T);
      for(int i(0); i<9; ++i) fprintf( fp, "%.6f, ", R[i]);
      for(int i(0); i<3; ++i) fprintf( fp, "%.6f, ", T[i]);
      fprintf( fp, "\n");
      fclose(fp);
      // for(int i(0); i<3; ++i) printf("%.6f, ", T[i]);
      // printf("\n");
      std::cout << " ... done" << std::endl;
    }

    if(_service_flag){
      // if( m_ObjectPose.tm.sec > _invokeTime.sec ) {
      // 	std::cout << "New Object pose : " << m_ObjectPose.tm.sec << " > "<<  _invokeTime.sec << std::endl;
      // 	_service_flag = false; 
      // }
      // else if ( m_ObjectPose.tm.sec == _invokeTime.sec ){
      // 	if ( m_ObjectPose.tm.nsec > _invokeTime.nsec ){
      // 	  std::cout << "New Object pose : " << m_ObjectPose.tm.sec << "."<<  m_ObjectPose.tm.nsec << " > "<<  _invokeTime.sec << "." << _invokeTime.nsec << std::endl;
      // 	  _service_flag = false; 
      // 	}
      // }
      if( _obj.getTimeStamp().sec > _invokeTime.sec ) {
	std::cout << "New Object pose : " << _obj.getTimeStamp().sec << " > "<<  _invokeTime.sec << std::endl;
	_service_flag = false; 
      }
      else if ( _obj.getTimeStamp().sec == _invokeTime.sec ){
	if ( _obj.getTimeStamp().usec*1000 > _invokeTime.nsec ){
	  std::cout << "New Object pose : " << _obj.getTimeStamp().sec << "."<<  m_ObjectPose.tm.nsec << " > "<<  _invokeTime.sec << "." << _invokeTime.nsec << std::endl;
	  _service_flag = false; 
	}
      }

      //    _exec_flag = false;
    }
  }
  // // display object pose on robot frame
  // if(m_display == "on"){
  //   m_ObjInfoService.displayObjectInfo();
  // }else{
  //   m_ObjInfoService.closeDisplayWindow();
  // }

  return RTC::RTC_OK;
}

/*
RTC::ReturnCode_t ObjectInfoManager::onAborting(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t ObjectInfoManager::onError(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t ObjectInfoManager::onReset(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t ObjectInfoManager::onStateUpdate(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/

/*
RTC::ReturnCode_t ObjectInfoManager::onRateChanged(RTC::UniqueId ec_id)
{
  return RTC::RTC_OK;
}
*/


void ObjectInfoManager::invokeEvent(const RIMSServiceSVC_impl &rss){
  std::cout << "invokeEvent called " << std::endl;
  
  //set accepted key
  std::string acKey = rss.getCurrentObjKey();

  // send model/object key to recognition component
  AcceptModelService::OctetSeq model;	model.length(acKey.length());
  memcpy(&model[0], acKey.c_str(), sizeof(char)*acKey.length());

  std::cout << "start set model  " << std::endl;	
  if(_modelPortC > 0){
    try{
      std::cout << "object model is " << std::ends;
      m_ModelAcceptor->setModel(model);
      std::cout << "changed. : [" << acKey << "]" << std::endl;

      _cObjKey = acKey;
    }
    catch(...){
      std::cout << "not changed." << std::endl;
    }
  }

  // // get Time 
  // RTC::Time startTime, capTime;
  // startTime = ALTH::UTIL::getCurrentTimeStamp();
  _invokeTime = ALTH::UTIL::getCurrentTimeStamp();
  std::cout << "[Debug] Starting time to get object pose = " << _invokeTime.sec << "."<< _invokeTime.nsec << std::endl;  
    

  string mode = rss.getMode();
  ObjectInformation oi;
  double objPose[12];
  double start, result, pre_result;
  int count=0;
  
  std::cout << "start get object pose "<< std::endl;
  // waiting object pose with current key 
  while( !_objManager.queryObjectInfo(acKey, oi) ){
    coil::usleep(10000);
    count++;
    //std::cout << count <<std::ends;
  }
  std::cout << "end get object pose, count =  " << count << std::endl;
  // mode : getNewObjectPose  
  // waiting new object pose with current key 
  if( mode == "getNew" ){
    _service_flag = true;
    count = 0;
    // pre_result = 0; 
    // start  = startTime.sec -_preTm.sec + startTime.nsec * 10e-9 - _preTm.nsec * 10e-9;
    // //std::cout << "start time = " << start  << std::endl; 
    
    // std::cout << "[Debug] Starting time to get object pose :            = " << startTime.sec << "."<< startTime.nsec << std::endl;  
    
    
    
    while(_service_flag){
      // _objManager.queryObjectInfo(acKey, oi);
      // result = oi.getTimeStamp().sec - _preTm.sec + oi.getTimeStamp().usec * 10e-6 - _preTm.nsec * 10e-9; 
      
      // if( fabs( pre_result - result ) > 0.001  ){
      // 	std::cout << "[Debug] Time  of Recognition result                   = " << oi.getTimeStamp().sec << "."<< oi.getTimeStamp().usec << std::endl; 
      // 	pre_result = result;
      // }
      // // else
      // // 	std::cout << << std::end;
      // if( (result - start)  > 0 ){
      // 	//std::cout << "result= " << result << std::endl; 
      // 	break;
      // }
      count++;
      coil::usleep(10000);
    }
  }
  std::cout << "[debug] count = " << count << std::endl;
  // success getting Object Pose 
  //if( count < 100 ){
  _objManager.queryObjectInfo(acKey, oi);
  oi.getPose(objPose);
  m_RIMSService.setObjectPose(objPose);
  m_RIMSService.getResult();
  //}
  
}
 

extern "C"
{
 
  void ObjectInfoManagerInit(RTC::Manager* manager)
  {
    coil::Properties profile(objectinfomanager_spec);
    manager->registerFactory(profile,
                             RTC::Create<ObjectInfoManager>,
                             RTC::Delete<ObjectInfoManager>);
  }
  
};


