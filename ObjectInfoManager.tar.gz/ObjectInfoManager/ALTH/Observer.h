#ifndef _OBSERVER_H_
#define _OBSERVER_H_

//
// Observer.h
//
// @breif this header provides "Observer pattern"
// @author H.Takahashi, Osaka Univ.
//
// @last modified in Sep., 2009
//
#include <list>
#include <typeinfo>

namespace ALTH{

	// abstract class of Observer
	class Observer;
	// super class of subject
	class ObsSubject;

	//
	// abstract class of Observer
	// definition
	class Observer
	{
	// if Observer wants to delete subject, 
	// Observer should have reference of ObsSubject.
	// http://mojalog.com/2008/05/post_193.html
	//private:
	//	ObsSubject *_obssub;
	//public:
	//	void addObsSubject(ObsSubject* obss){
	//		obss.add
	//	}
	public:
		virtual ~Observer(){}
		virtual void update(ObsSubject *obss=0)=0;
	};

	//
	// super class of subject
	// definition
	class ObsSubject
	{
	private:
		std::list<Observer*> _obslist;
	public:
		virtual ~ObsSubject(){}
		void addObs(Observer* o){_obslist.push_back(o);}
		void deleteObs(Observer* o){_obslist.remove(o);}
		void deleteObs(){_obslist.clear();}
		void notifyObs(){
			std::list<Observer*>::iterator it = _obslist.begin();
			while(it != _obslist.end()){
				(*it)->update(this);
				++it;
			}
		}
	};

};

#endif //_OBSERVER_H_