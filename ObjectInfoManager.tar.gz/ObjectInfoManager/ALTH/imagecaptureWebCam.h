#ifndef _WEB_CAM_H_
#define _WEB_CAM_H_

#include "imagecapture.h"

//
// WebCam class
//
// @author Hideyasu TAKAHASHI
// @last modified in Sep., 2009
//


//=============================================================================
// include OpenCV
//=============================================================================
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>

namespace ALTH{


//=============================================================================
// WebCam class
// @ brief: this class supports web camera (USB camera) on windows/linux.
// @ output RGB/BGR image
// @ Note: this class depends on OpenCV library.
//         Please set cv.lib, cxcore.lib, and highgui.lib for web camera 
//=============================================================================
class WebCam : public ImageCapture
{
public:
	//constructor
	WebCam();
	//destructor
	~WebCam();
//---------------------------------------------------------------
// OpenCV's variable and function
//---------------------------------------------------------------
private:
	CvCapture *_capture;              // CvCapture handler
	IplImage *_image;                  // image buffer

//--------------------------------------------------------------
// common function for camera controll
//--------------------------------------------------------------
public:
	// open camera
	bool Opens();

	// close camera
	bool Closes();

	// capture image
	// @param
	//  unsigned char* buffer : image buffer
	bool CaptureImages(unsigned char* buffer);
};

};

#endif //_WEB_CAM_H_
