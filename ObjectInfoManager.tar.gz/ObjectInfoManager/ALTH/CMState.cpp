//
// This '.cpp' file is implementation of StateManager class
// for 'ComponentManager-Component'.
//
// @author H.Takahashi, Osaka Univ.
// last modified in Oct.,2009
//

#include "CMState.h"

namespace ALTH{
	namespace CM{
		// get label
		char* getLabel(cmanager_s state){
			switch(state){
			case CMANAGER_UNEXPECTED_ERROR : return "CMANAGER_UNEXPECTED_ERROR";
			case CMANAGER_ERROR : return "CMANAGER_ERROR";
		//	case CMANAGER_INITIAL : return "CMANAGER_INITIAL";
			case CMANAGER_IDLE : return "CMANAGER_IDLE";
			case CMANAGER_ACTIVE : return "CMANAGER_ACTIVE";
		//	case CMANAGER_DONE : return "CMANAGER_DONE";
		//	case CMANAGER_STOP : return "CMANAGER_STOP";
		//	case CMANAGER_FINALIZE : return "CMANAGER_FINALIZE";
			}
			return NULL;
		}

/*
		//================== implementation of CMxxxState Class ======================

		//-------------------------- unexpected error --------------------------------


		//---------------------------- error state -----------------------------------
		CMErrorState* CMErrorState::_inst = NULL;

		CMErrorState::~CMErrorState(){
		}

		// execute function
		void CMErrorState::entry(){if(verbose) std::cout << "CMErrorState" << std::endl;}
		CMState<cmanager_s>* CMErrorState::maindo(){return CMErrorState::instance();}
		void CMErrorState::exit(){}

		//--------------------------- initial state ----------------------------------


		//----------------------- idle state(do nothing) -----------------------------
		CMIdleState* CMIdleState::_inst = NULL;

		CMIdleState::~CMIdleState(){
		}

		// execute function
		void CMIdleState::entry(){if(verbose) std::cout << "CMIdleState" << std::endl;}
		CMState<cmanager_s>* CMIdleState::maindo(){return CMIdleState::instance();}
		void CMIdleState::exit(){}
		//---------------------------- active state() --------------------------------
		//CMState* CMActiveState::action(CMContext *cmc){
		//	std::cout << "CMActiveState" << std::endl;

		//	// if sub-active state is 'NULL', current state transfars to 'idle' state.
		//	if( getCurrenState() != 0){
		//		// do something (sub-active state)
		//		changeState(_cmState->action(this));

		//		return CMActiveState::instance();
		//	}
		//	return CMIdleState::instance();
		//}

		//--------------------------- behavior is done -------------------------------


		//--------------------------- stop all behavior ------------------------------


		//----------------------------- finalize state -------------------------------
*/
	};// namespace CM
};// namespace ALTH
//============================= test code ====================================
#if 0
#include <iostream>
using namespace ALTH;
using namespace ALTH::CM;
int main(){
	std::cout << "test of 'CManagerState'" << std::endl;
	CM::cmanager_s cms=CM::CMANAGER_ACTIVE;
	CM::cmanager_s cms2=CM::CMANAGER_IDLE;
	std::cout << "current sate: " <<  CM::getLabel(cms) << std::endl;
	cms=cms2;
	std::cout << "current sate: " <<  CM::getLabel(cms) << std::endl;
	cms2=CM::CMANAGER_IDLE;
	if(cms==cms2){
		std::cout << "current sate: " <<  CM::getLabel(cms) << std::endl;
	}

	std::cout << "<Push any key>" << std::ends;
	getchar();

	std::cout << "test of CMState class and CMContext class" << std::endl;
	{
		CM::CMIdleState is;
		CM::CMActiveState<cmanager_s> as;
		CM::StateContext<CMState<cmanager_s>> cmc(&is);
		for(int i=0; i<30; ++i){
			cmc();

			std::cout << "change state->CMActiveState" << std::endl;
			cmc.changeState(&as);
			cmc();
		}
	}
	std::cout << "<Push any key>" << std::ends;
	getchar();
	return 0;
}
#endif
//========================== end of test code ================================
