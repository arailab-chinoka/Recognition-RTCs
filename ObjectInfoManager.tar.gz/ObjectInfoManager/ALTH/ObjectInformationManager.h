#ifndef _OBJECT_INFOMATION_MANAGER_H_
#define _OBJECT_INFOMATION_MANAGER_H_

//
// ObjectInfomationManager.h
//
// @breif this header provides 'Object infomation manager' function.
// @author H.Takahashi, Osaka Univ.
//
// @last modified in Nov. 2009
//

#include <iostream>
#include <string>
#include <list>
#include <string.h>
#include "ImageViewer.h"

namespace ALTH{

//
// ObjectInformation class
//
// @breif Data structure for object information
//
class ObjectInformation
{
public:
	// definition of time stamp
	class TimeStamp{
	public:
		long int sec;
		long int usec;
		TimeStamp(){}
		TimeStamp(const TimeStamp& tm){ sec=tm.sec; usec=tm.usec; }
		TimeStamp& operator=(const TimeStamp& tm){sec=tm.sec; usec=tm.usec; return (*this);}
	};
protected:
	TimeStamp _tm; //time stamp

	std::string _key; // object ID or name

	// object pose
	double _R[9]; // rotation matrix
	double _T[3]; // translation vector

public:
	// constructor
	ObjectInformation()
		: _key(""){}
	ObjectInformation(double R[9], double T[3], std::string key="")
		: _key(key){
			setPose(R,T);
	};
	ObjectInformation(double H[12], std::string key="")
		: _key(key){
			setPose(H);
	};

	// destructor
	~ObjectInformation(){}

	// copy constructor
	ObjectInformation(const ObjectInformation& obj);

	// assignment operator overload
	ObjectInformation &operator=(const ObjectInformation &obj);
	bool operator==(const ObjectInformation& obj){
		return (obj._key == this->_key);
	}

	// set Information
	inline void setRotation(double R[9]){
		memcpy(_R, R, sizeof(double)*9);
	}
	inline void setTranslation(double T[3]){
		memcpy(_T, T, sizeof(double)*3);
	}
	inline void setPose(double R[9], double T[3]){
		setRotation(R);
		setTranslation(T);
	}
	inline void setPose(double H[12]){
		_R[0]=H[0]; _R[1]=H[1]; _R[2]=H[2]; _T[0]=H[3]; 
		_R[3]=H[4]; _R[4]=H[5]; _R[5]=H[6]; _T[1]=H[7]; 
		_R[6]=H[8]; _R[7]=H[9]; _R[8]=H[10]; _T[2]=H[11]; 
	}
	inline void setKey(std::string key){
		_key = key;
	}
	inline void setInformation(std::string key, double R[9], double T[3]){
		setPose(R,T);
		setKey(key);
	}
	inline void setInformation(std::string key, double H[12]){
		setPose(H);
		setKey(key);
	}
	inline void setTimeStamp(long int sec, long int usec){
		_tm.sec=sec; _tm.usec = usec;
	}

	// get Information
	inline std::string getKey()const{return _key;}
	inline void getRotation(double R[])const{
		memcpy(R, _R, sizeof(double)*9);
	}
	inline void getTranslation(double T[])const{
		memcpy(T, _T, sizeof(double)*3);
	}
	inline void getPose(double R[], double T[])const{
		getRotation(R);
		getTranslation(T);
	}
	inline void getPose(double H[])const{
		H[0]=_R[0]; H[1]=_R[1]; H[2]=_R[2]; H[3]=_T[0];
		H[4]=_R[3]; H[5]=_R[4]; H[6]=_R[5]; H[7]=_T[1];
		H[8]=_R[6]; H[9]=_R[7]; H[10]=_R[8]; H[11]=_T[2];
	}
	inline void getInformation(std::string &key, double R[], double T[])const{
		key=getKey();
		getPose(R,T);
	}
	inline void getInformation(std::string &key, double H[])const{
		key=getKey();
		getPose(H);
	}
	inline void getTimeStamp(long int &sec, long int &usec)const{
		sec = _tm.sec; usec = _tm.usec;
	}
	inline TimeStamp getTimeStamp()const{
		return _tm;
	}
	inline long getTimeSec()const{
	  return _tm.sec;
	}
	inline long getTimeUsec()const{
	  return _tm.usec;
	}
	// print information
	inline void printAllInfomation()const{
		std::cout << "key:" << _key << "\n"
			<< "time stamp:" << _tm.sec << "[sec] " << _tm.usec << "[usec]\n" 
			<< "rotation matrix:\n"
			<< "[" << _R[0] << " " << _R[1] << " " << _R[2] << "]\n"
			<< "[" << _R[3] << " " << _R[4] << " " << _R[5] << "]\n"
			<< "[" << _R[6] << " " << _R[7] << " " << _R[8] << "]\n"
			<< "translation matrix:\n"
			<< "[" << _T[0] << " " << _T[1] << " " << _T[2] << "]\n" << std::endl;
	}
};


//
// Object Infomation Manager class with observer
// @brief 
class ObjectInformationManager
{
protected:
	// list of Object information
	mutable std::list<ObjectInformation> _objList;

private:
	// window to display object pose
	ImageViewer _iv;

	// buffer to display objcet pose
	unsigned char* _dispbuf;

public:
	// constructor
	ObjectInformationManager();

	// destructor
	virtual ~ObjectInformationManager();

	// query object information with key
	// @param key : key of object
	// @return object information
	bool queryObjectInfo(std::string key, ObjectInformation &obj)const;

	// register object information
	// @param obj : object information
	void registerObjectInfo(const ObjectInformation& obj);

	// delete object information
	void deleteAllObjectInfo();
	void deleteObjectInfo(std::string key);

	// display object information
	bool displayObjectInfo();
	bool closeDisplayWindow();
};


}; //namespace ALTH

#endif //_OBJECT_INFOMATION_MANAGER_H_
