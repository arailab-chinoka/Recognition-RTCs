#include "CfgFileLoader.h"

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <fstream>
#include <vector>
using namespace std;

namespace ALTH{
	//---------------------------------------------------------
	// split
	//
	// @param string str ����������������
	// @param string delim �f���~�^
	// @return vector<string> �������ꂽ������
	//---------------------------------------------------------
	vector<string> Cfg::split(string str, string delim) {
	  vector<string> result;

	  for(string::size_type i=0, n; i <= str.length(); i=n+1){
		n = str.find_first_of(delim, i);
		if(n == string::npos ) n = str.length();
		string tmp = str.substr(i, n-i);
		result.push_back(tmp);
	  }

	  return result;
	}



	void func(){
		string filebuf;// buffer
		ifstream ifs("camera.cfg");// file name

		// read file
		while(ifs && getline(ifs, filebuf)){
			// one line
			// convert ',' -> ' '
			std::replace( filebuf.begin(), filebuf.end(), ',', ' ');

			// remove comment "#hoge"
			int com_index = filebuf.find('#');
			if (com_index != string::npos){
				filebuf = filebuf.substr(0, com_index);
			}

			// discription command
			string indexcommand[2]={"CameraParameter", "RightCameraParameter"};
			const int indcomNum(sizeof indexcommand/sizeof indexcommand[0]);
			string indexparameter[3]={"Intrinsic1", "Intrinsic2", "Distortion"};
			const int indparNum(sizeof indexparameter/sizeof indexparameter[0]);

			// vector
			vector<double> parameter[indcomNum]; // for parameter

			// search command
			for (int i=0; i<indcomNum; ++i){
				com_index = filebuf.find(indexcommand[i]);
				if (com_index != string::npos){ //indexcommand[i] is found
					// remove index-command
					filebuf = filebuf.substr(strlen(indexcommand[i].c_str())+com_index);

					// split string to command and parameter
					vector<string> vecstr; //vecstr[0]:command  vecstr[1]:parameter
					vecstr = Cfg::split(filebuf, ":");

					// search command
					for (int j=0; j<indparNum; ++j){
						com_index = filebuf.find(indexparameter[j]);
						if (com_index != string::npos){
						}
					}
				}
			}
		}

			// convert string to double
			std::istringstream iss(filebuf);
	}

};


//======================== test code ================================
#if 0
using namespace ALTH;
int main(){
	Cfg::CfgFileLoader<double> cfgloader("sample.cfg");
	//
	// sample.cfg
	//
	// TestValue : 0.23, 0.34, 2.4
	// TestValue2: 1.0, 2.0
	//
	cfgloader.setNewCommand("TestValue", 3);
	cfgloader.setNewCommand("TestValue2", 2);
	cfgloader.loadCfgFile();
	std::vector<double> p = cfgloader.getParameter("TestValue");
	for(int i=0; i<p.size(); ++i){
		std::cout << "TestValue parameter" << i << " is "<< p[i] << std::endl;
	}
	for(int i=0; i<p.size(); ++i){
		std::cout << "TestValue2 parameter" << i << " is " << p[i] << std::endl;
	}
	return 0;
}

#endif
//==================== end of test code =============================