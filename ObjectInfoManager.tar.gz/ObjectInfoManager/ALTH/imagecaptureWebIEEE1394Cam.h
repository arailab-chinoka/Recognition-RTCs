#ifndef _WEBIEEE1394CAM_H_
#define _WEBIEEE1394CAM_H_

#include "imagecapture.h"
#include "imagecaptureIEEE1394Cam.h"
#include "imagecaptureWebCam.h"

//
// WebIEEE1394Cam class
//
// @author Hideyasu TAKAHASHI
// @last modified in Sep., 2009
//

namespace ALTH{

//=============================================================================
// WebIEEE1394Cam class
// @ brief: this class supports point gray camera (bumblebee2 and flea2 ) on windows
//   and supports web camera (USB camera) on windows/linux.
// @ output RGB/BGR image
// @ Note: Plese set pgrflycapture.lib for point gray camera,
//         and set cv.lib, cxcore.lib, and highgui.lib for web camera 
//=============================================================================
class WebIEEE1394Cam
{
private:
	// pointer for capture class's instance
	WebCam* _webcam;
	IEEE1394Cam* _ieee1394cam;

//---------------------------------------------------------------
// camera state
//---------------------------------------------------------------
private:      
	bool _captureCamera;   // point gray camera:"false"
	                       // web camera:"true"

// get/set function for camera state
public:
	// @param
	//    stereo(for bumblebee): "true/false", true:both, false:right
	//                         : monocular camera:"false"
	bool setStereo(bool stereo);
	bool getStereo();
	// @param
	//     camera: true(web camera), false(firewire camera)
	void setCaptureCamera(bool camera);
	bool getCaptureCamera();

//--------------------------------------------------------------
// common function for camera controll
//--------------------------------------------------------------
public:
	// constructor
	WebIEEE1394Cam();
	// constructor
	// @param
	//   camera : web/IEEE1394
	//   stereo : stereo/single
	WebIEEE1394Cam(bool camera, bool stereo);

	// destructor
	~WebIEEE1394Cam();

	// open camera
	bool Opens();
	// open camera
	// @param
	//   camera : web/IEEE1394
	//   stereo : stereo/single
	bool Opens(bool camera, bool stereo);

	// close camera
	bool Closes();

	// capture image
	// @param
	//  unsigned char* buffer : image buffer
	bool CaptureImages(unsigned char* buffer);
	// capture image
	// @param
	//  bufferL : image buffer of Left Camera
	//  bufferR : image buffer of Right Camera
	bool CaptureImages(unsigned char* bufferL, unsigned char*bufferR);

	// image size
	// @param
	//  w : image's width
	//  h : image's height
	void setImageSize(int w, int h); // unpopulated function
	void getImageSize(int* w, int* h);

	// pixeltype
	// @pixel type                        @number
	//  PIXEL_GRAY   (1 channels/pixel)      1
	//  PIXEL_GRAYA  (2 channels/pixel)      2
	//  PIXEL_RGB    (3 channels/pixel)      3
	//  PIXEL_RGBA   (4 channels/pixel)      4
	//  PIXEL_BGR    (3 channels/pixel)      5
	//  PIXEL_YUV    (3 channels/pixel)      6
	pixel_t getPixelType();
	void setPixelType(pixel_t ptype);

	bool getActivated();
};


}; //namespace ALTH

#endif //_WEBIEEE1394CAM_H_