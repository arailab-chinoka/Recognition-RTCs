#ifndef _CM_STATE_
#define _CM_STATE_

//
// CMState.h
//
// @breif Definition of Component Manager's state
//
// @author H.Takahashi, Osaka Univ.
// @last modified Oct. 2010 by K.Iwane to linux version
// 
//



#include "MultiCastEventListener.h"
//#include "MutexUtil.h"
#include <iostream>
#include <memory>

namespace ALTH{

	namespace CM{
		// definition of state
		typedef enum {
			CMANAGER_UNEXPECTED_ERROR = 0x0000, // unexeped error
			CMANAGER_ERROR,                // error state
		//	CMANAGER_INITIAL,              // initial state
			CMANAGER_IDLE,                 // idle state(do nothing)
			CMANAGER_ACTIVE,               // active state()
			CMANAGER_DONE,                 // behavior is done
		//	CMANAGER_STOP,                 // stop all behavior
		//	CMANAGER_FINALIZE              // finalize state
		}cmanager_s;

		// get label
		char* getLabel(cmanager_s state);
		/*char* getLabel(cmanager_s state){
			switch(state){
			case CMANAGER_UNEXPECTED_ERROR : return "CMANAGER_UNEXPECTED_ERROR";
			case CMANAGER_ERROR : return "CMANAGER_ERROR";
		//	case CMANAGER_INITIAL : return "CMANAGER_INITIAL";
			case CMANAGER_IDLE : return "CMANAGER_IDLE";
			case CMANAGER_ACTIVE : return "CMANAGER_ACTIVE";
		//	case CMANAGER_DONE : return "CMANAGER_DONE";
		//	case CMANAGER_STOP : return "CMANAGER_STOP";
		//	case CMANAGER_FINALIZE : return "CMANAGER_FINALIZE";
			}
			return NULL;
		}
		*/
/*
		// handle(context) class of component manager
		template<class State>
		class StateContext: public EventSource<State*>
		{
		private:
		  //ALTH::UTIL::Mutex _thread_sync;
		protected:
			State* _preState; // previous state
			State* _cState; // current state

		public:
			
			// constructor
			// @param *state : initial state of component manager
			StateContext():_cState(0){_preState=_cState;}
			StateContext(State *state){_cState = state; _preState=_cState;}

			// destructor
			~StateContext(){}

			// change component manager's state
			// @param nextState: next state of compoenent manager
			// @return Current state which is set.
			State* changeState(State* nextState=0){
			  //_thread_sync.lock();

				if(_cState != nextState){
					if(_cState != 0){
						_cState->exit();
					}
					_preState = _cState;
					_cState = nextState;
					_cState->setSelf(this);

					// notify change of state to someone
					notifyEvent(_cState);

					if(_cState!=0){_cState->entry();}
				}

				//_thread_sync.unlock();
				return _cState;
			}

			// get current manager's state
			State* getCurrentState() const{
				return _cState;
			}

			// do something
			void operator()(){
			  //_thread_sync.lock();
			  if (_cState == 0){//_thread_sync.unlock(); return;}
				(*this).changeState(_cState->maindo());
				//_thread_sync.unlock();
			}
		};

		// interface class of component manager's state
		template<class StateType_T>
		class CMState{
		public:
			bool verbose;
		public:
			CMState():verbose(false){}
			
			virtual ~CMState(){}
			
			// execute function
			virtual void entry()=0;
			virtual CMState<StateType_T>* maindo()=0;
			virtual void exit()=0;

			// get current state
			virtual StateType_T getState()const=0;
			
			// inheritance class should have the 'instance()' function as follows.
			//
			// static CMxxState* instance();
			// this function returns static instance of concrete state class.
		};

		// Previous declaration
		// State class of component manager
		//
		// Note:Instance of CMxxState class must be only one.
		//
		//class CMUnexpectedErrorState  // unexeped error
		class CMErrorState;           // error state
		//class CMInitialState;         // initial state
		class CMIdleState;            // idle state(do nothing)
		template<class StateType> class CMActiveState;          // active state()
		//class CMDoneState;            // behavior is done
		//class CMStopState;            // stop all behavior
		//class CMFinalizeState;        // finalize state


		//// unexeped error
		//class CMUnexpectedErrorState : public CMState


		// error state
		class CMErrorState : public CMState<cmanager_s>
		{
		private:
			static CMErrorState *_inst;

		public:
			// execute function
			void entry();
			CMState<cmanager_s>* maindo();
			void exit();

			CMErrorState(){_inst = this;}
			~CMErrorState();

			inline static CMErrorState* instance(){return _inst;}

			// get current state
			cmanager_s getState()const{return CM::CMANAGER_ERROR;}
		};

		//// initial state
		//class CMInitialState : public CMState

		// idle state(do nothing)
		class CMIdleState : public CMState<cmanager_s>
		{
		private:
			static CMIdleState *_inst;

		public:
			// execute function
			void entry();
			CMState<cmanager_s>* maindo();
			void exit();

			CMIdleState(){_inst = this;}
			~CMIdleState();

			inline static CMIdleState* instance(){return _inst;}

			// get current state
			cmanager_s getState()const{return CM::CMANAGER_IDLE;}
		};

		// active state
		// active state has sub-state
		template<class SubActStateType>
		class CMActiveState
			: public CMState<cmanager_s>,
			  public StateContext< CMState<SubActStateType> >
		{
		private:
			static CMActiveState *_inst;

		public:
			// execute function
			void entry(){ if(verbose) std::cout << "CMActiveState" << std::endl; }
			CMState<cmanager_s>* maindo(){ 
				if( getCurrentState() !=0){
					// do something (sub-active state)
					changeState(_cState->maindo());

					return CMActiveState<SubActStateType>::instance();
				}
				return CMIdleState::instance();
			}
			void exit(){
				if( getCurrentState() != 0 ){
					_cState->exit();
				}
			}

			CMActiveState(){_inst = this; StateContext<CMState<SubActStateType>>::_cState = 0; StateContext<CMState<SubActStateType>>::_preState = 0;}
			~CMActiveState(){}

			inline static CMActiveState<SubActStateType>* instance(){return _inst;}

			// get current state
			cmanager_s getState()const{return CM::CMANAGER_ACTIVE;}

			// get current substate
		};
		template<class SubActStateType>
		CMActiveState<SubActStateType>* CMActiveState<SubActStateType>::_inst = NULL;

		//// behavior is done
		//class CMDoneState : public CMState


		//// stop all behavior
		//class CMStopState : public CMState


		//// finalize state
		//class CMFinalizeState : public CMState
		*/

	}; // namespace CM
}; // namespace ALTH

#endif //_COMPONENT_MANAGER_STATE_
