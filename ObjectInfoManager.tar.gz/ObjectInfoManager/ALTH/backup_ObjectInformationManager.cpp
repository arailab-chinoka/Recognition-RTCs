#include "ObjectInformationManager.h"

namespace ALTH{

//=================== implementation of "ObjectInformation" ============================
// copy constructor
ObjectInformation::ObjectInformation(const ObjectInformation& obj){
	// copy all data
	memcpy((*this)._R, obj._R, sizeof(double)*9);
	memcpy((*this)._T, obj._T, sizeof(double)*3);
	_key = obj._key;
	_tm = obj._tm;
}

// assignment operator overload
ObjectInformation &ObjectInformation::operator=(const ObjectInformation &obj){
	// copy all data
	memcpy((*this)._R, obj._R, sizeof(double)*9);
	memcpy((*this)._T, obj._T, sizeof(double)*3);
	_key = obj._key;
	_tm = obj._tm;

	return (*this);
}

//===================== implementation of "ObjectInformationManager" ==================

// query object information with key
// @param key : key of object
// @return object information
bool ObjectInformationManager::queryObjectInfo(std::string key, ObjectInformation &obj)const
{
	std::list<ObjectInformation>::const_iterator it = _objList.begin();

	while(it != _objList.end()){
		if((*it).getKey() == key){
			// same key is exist
			obj = (*it);
			return true;
		}
		++it;
	}

	// object is not found
	return false;
}

// register object information
// @param obj : object information
void ObjectInformationManager::registerObjectInfo(const ObjectInformation& obj){
	std::list<ObjectInformation>::iterator it = _objList.begin();

	while(it != _objList.end()){
		if(it->getKey() == obj.getKey()){
			// now, same key is exist.
			// copying object's value
			(*it) = obj;
			return;
		}
		++it;
	}

	// same key is not exist
	// add value into list
	_objList.push_back(obj);
}


}; // namespace ALTH

//===================================== test code =====================================
#if 0
#include <iostream>
using namespace ALTH;
int main()
{
	std::cout << "ObjectInformation class test" << std::endl;
	ObjectInformationManager oim;
	ObjectInformation oi;
	double H[12]={1.0, 0.0, 0.0, 1.0,
		          0.0, 1.0, 0.0, 1.0,
	              0.0, 0.0, 1.0, 1.0 };
	ObjectInformation oi2(H, "hoge");
	oi2.printAllInfomation();
	oi.setInformation("crunky", H);
	oim.registerObjectInfo(oi);
	std::cout << "register object information->crunky" << std::endl;
	oi.printAllInfomation();

	H[0]=0.0;H[1]=0.0;H[2]=1.0;H[3]=-1.0;
	H[4]=0.0;H[5]=1.0;H[6]=0.0;H[7]=0.0;
	H[8]=1.0;H[9]=0.0;H[10]=0.0;H[11]=1.0;
	oi.setInformation("tea_bottle", H);
	oim.registerObjectInfo(oi);
	std::cout << "register object information->tea_bottle" << std::endl;
	oi.printAllInfomation();

	H[0]=0.0;H[1]=0.0;H[2]=1.0;H[3]=-1.0;
	H[4]=0.0;H[5]=1.0;H[6]=0.0;H[7]=1.0;
	H[8]=1.0;H[9]=0.0;H[10]=0.0;H[11]=1.0;
	oi.setInformation("tea_bottle", H);
	oim.registerObjectInfo(oi);
	std::cout << "register object information->tea_bottle" << std::endl;
	oi.printAllInfomation();

	std::cout << "query object information->tea_bottle" << std::endl;
	if(oim.queryObjectInfo("tea_bottle", oi)){oi.printAllInfomation();}
	else{std::cout << "false" << std::endl;}

	std::cout << "query object information->crunky" << std::endl;
	if(oim.queryObjectInfo("crunky", oi)){oi.printAllInfomation();}
	else{std::cout << "false" << std::endl;}

	std::cout << "query object information->hoge" << std::endl;
	if(oim.queryObjectInfo("hoge", oi)){oi.printAllInfomation();}
	else{std::cout << "false" << std::endl;}

	std::cout << "end test" << std::endl;
	std::cout << "<Press any key>" << std::ends;
	getchar();
	return 0;
}
#endif
//================================= end of test code ==================================