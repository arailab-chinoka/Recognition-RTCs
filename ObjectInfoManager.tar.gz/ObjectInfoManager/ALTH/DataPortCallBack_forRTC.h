#ifndef _DATA_PORT_CALL_BACK_FOR_RTC_H_
#define _DATA_PORT_CALL_BACK_FOR_RTC_H_

//
// DataPortCallBack_forRTC.h
//
// @brief Classes in this header provide callback function for RTC.
// @author H.Takahashi, Osaka Univ.
// @last modified Oct., 2009
//

// include port callback definition
#include <rtm/PortCallBack.h>
#include <rtm/idl/BasicDataTypeSkel.h>

#include "vm_macros.h"
#include <string>
#include <iostream>

namespace ALTH{

namespace TC{ // Transform Coordinate

// transformation type
typedef enum { TRANS_ERROR =0, //not use
	TRANS_HOMOGENEOUS,
	TRANS_HOMOGENEOUS_R_T,
	TRANS_XYZ_ROLL_PITCH_YAW
} trans_t;

// get label
char* getLabel(trans_t type);

// 
// @param str: transformation type
trans_t transLabel2Enum(const char* str);

//
// OnWritePoseTransDoubleSeq class
//
// @brief this class transform coordinate system.
//        Please set this class to "RTC::InPort<RTC::TimedDoubleSeq>::setOnWriteConvert()".
class OnWritePoseTransDoubleSeq
	: public RTC::OnWriteConvert<RTC::TimedDoubleSeq>
{
private:
	double _tR[9]; //rotation matrix [3*3]
	double _tT[3]; // translation matrix [3*1]

public:
	trans_t _outTransType; // output type of matrix
	trans_t _inTransType;  // input type of matrix

public:
	// constructor
	OnWritePoseTransDoubleSeq();
	OnWritePoseTransDoubleSeq(trans_t itype, trans_t otype);

	// destructor
	~OnWritePoseTransDoubleSeq();

	// set transform type
	// @param itype : transformation type of output
	//        otype : transformation type of input
	void setTransType(trans_t itype, trans_t otype);
	void setTransType(const char* itype, const char* otype);

	// set transform matrix
	// @param tR : rotation matrix [3*3]
	//        tT : translation matrix [3*1]
	void setTransMat(double tR[], double tT[]);
	// @param tH : homogeneous matrix [3*4]
	void setTransMat(double tH[]);

	// transform matrix
	// @param value : input matrix
	// @return converted pose matrix
	::RTC::TimedDoubleSeq operator()(const ::RTC::TimedDoubleSeq& value);

};


}; //namespace TC
}; //namespace ALTH

#endif //_DATA_PORT_CALL_BACK_FOR_RTC_H_