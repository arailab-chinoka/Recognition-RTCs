#ifndef _TRANSFORMMATRIX_H_
#define _TRANSFORMMATRIX_H_

//
// TransformMatrix.h
//
// @brief Classes provide transform matrix  
//        this class  is made by modified  DataPortCallback_forRTC.h 
// @author K.Iwane (H.Takahashi, Osaka Univ.)
// @last modified May., 2010 (Oct., 2009)
//

// include port callback definition
//#include <rtm/PortCallBack.h>
#include <rtm/idl/BasicDataTypeSkel.h>

#include "vm_macros.h"
#include <string>
#include <iostream>
#include <stdio.h>

namespace ALTH{

namespace TC{ // Transform Coordinate

// transformation type
typedef enum { TRANS_ERROR =0, //not use
	TRANS_HOMOGENEOUS,
	TRANS_HOMOGENEOUS_R_T,
	TRANS_XYZ_ROLL_PITCH_YAW
} trans_t;

// get label
char* getLabel(trans_t type);

// 
// @param str: transformation type
trans_t transLabel2Enum(const char* str);

//
// TransformMatrix class
//
// @brief this class transform coordinate system.
class TransformMatrix
{
private:
	double _tR[9]; //rotation matrix [3*3]
	double _tT[3]; // translation matrix [3*1]

public:
	trans_t _outTransType; // output type of matrix
	trans_t _inTransType;  // input type of matrix

public:
	// constructor
	TransformMatrix();
	TransformMatrix(trans_t itype, trans_t otype);

	// destructor
	~TransformMatrix();

	// set transform type
	// @param itype : transformation type of output
	//        otype : transformation type of input
	void setTransType(trans_t itype, trans_t otype);
	void setTransType(const char* itype, const char* otype);

	// set transform matrix
	// @param tR : rotation matrix [3*3]
	//        tT : translation matrix [3*1]
	void setTransMat(double tR[], double tT[]);
	// @param tH : homogeneous matrix [3*4]
	void setTransMat(double tH[]);

	
	// transform matrix
	// @param inmt  : input matrix
	// @param outmt : converted pose matrix
	void calculateTransformMatrix(double inmt[] , double  outmt[]);

	// transform matrix
	// @param value : input matrix
	// @return converted pose matrix
	//::RTC::TimedDoubleSeq operator()(const ::RTC::TimedDoubleSeq& value);

};


}; //namespace TC
}; //namespace ALTH

#endif //_TransformMatrix_H_
