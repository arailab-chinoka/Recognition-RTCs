#ifndef _QUATERNION_H_
#define _QUATERNION_H_

//
// Quaternion.h
//
// @brief this header provides functions to marge rotation matrix by quaternion
//        please refere to  http://www015.upp.so-net.ne.jp/notgeld/quaternion.html
//                          http://www.cvl.iis.u-tokyo.ac.jp/~miyazaki/tech/tech52.html
//                          http://hakuhin.hp.infoseek.co.jp/main/as/quaternion.html#QUAT_06
//                          http://marupeke296.com/DXG_No58_RotQuaternionTrans.html
//                          http://www23.atwiki.jp/yahirohumpty/pages/13.html
// @author H.Takahashi, Arai-lab, Osaka Univ.
// @last modified in Nov. 2009
//

#include <iostream>
#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif //_USE_MATH_DEFINES
#include <cmath>
#include "vm_macros.h"
namespace ALTH {
	inline double RAD2DEG(double x){
		return x*180.0/M_PI;
	}
	inline float RAD2DEG(float x){
		return (float)(x*180.0f/M_PI);
	}
	inline double DEG2RAD(double x){
		return x*M_PI/180.0;
	}
	inline float DEG2RAD(float x){
		return (float)(x*M_PI/180.0f);
	}
	namespace UTIL_MAT{
		const double EPS(1.0e-16f);

		class Quaternion{
		public:
			double w; //real-component
			double x; //x-component
			double y; //y-component
			double z; //z-component

			// constructor
			Quaternion()
				: w(1.0), x(0.0), y(0.0), z(0.0){}
			Quaternion(double w, double x, double y, double z)
				: w(w), x(x), y(y), z(z){}
			
			// operator over load
			Quaternion& operator+=(const Quaternion& q){
				this->w += q.w;
				this->x += q.x;
				this->y += q.y;
				this->z += q.z;
				return *this;
			}
			Quaternion operator+(const Quaternion& q){
				Quaternion ret(*this);
				return ret+=q;
			}
			Quaternion& operator-=(const Quaternion& q){
				this->w -= q.w;
				this->x -= q.x;
				this->y -= q.y;
				this->z -= q.z;
				return *this;
			}
			Quaternion operator-(const Quaternion& q){
				Quaternion ret(*this);
				return ret-=q;
			}
			
			Quaternion operator*(const Quaternion& q){
				Quaternion ret;
				
				ret.w = (*this).w * q.w - (*this).x * q.x - (*this).y * q.y - (*this).z * q.z;
				ret.x = (*this).w * q.x + (*this).x * q.w + (*this).y * q.z -(*this).z * q.y;
				ret.y = (*this).w * q.y + (*this).y * q.w + (*this).z * q.x -(*this).x * q.z;
				ret.z = (*this).w * q.z + (*this).z * q.w + (*this).x * q.y - (*this).y * q.x;

				return ret;
			}

			Quaternion& operator*=(const Quaternion& q){
				*this = (*this)*q;

				return *this;
			}

			Quaternion& operator*=(const double& s){
				this->w *= s;
				this->x *= s;
				this->y *= s;
				this->z *= s;
				return *this;
			}

			Quaternion operator*(const double& s){
				Quaternion ret(*this);
				return ret*=s;
			}

			Quaternion& operator/=(const double& s){
				x/=s;
				y/=s;
				z/=s;
				w/=s;
				return *this;
			}

			Quaternion operator/(const double& s){
				Quaternion ret(*this);
				ret/=s;
				return *this;
			}

			// this function converts rotation matrix to quaternion.
			// quaternion is stored in this class.
			// @param R[9] : rotation matrix
			// @return quaternion
			inline Quaternion& convRotMat2Quat(const double R[9]){
				double elm[4]; // 0:x 1:y 2:z 3:t
				elm[0] = R[0] - R[4] - R[8] + 1.0;
				elm[1] =-R[0] + R[4] - R[8] + 1.0;
				elm[2] =-R[0] - R[4] + R[8] + 1.0;
				elm[3] = R[0] + R[4] + R[8] + 1.0;

				int maxIndex(0);
				for(int i(0); i<4; ++i){
					if(elm[i] > elm[maxIndex]) maxIndex = i;
				}

				// error check
				if(elm[maxIndex] < 0.0){ 
					w=0.0; x=0.0; y=0.0; z=0.0;
					return *this;
				}

				// calculate max element
				double *pq[4] = {&x, &y, &z, &w};
				double v = sqrt(elm[maxIndex]) * 0.5;
				*pq[maxIndex] = v;
				double mult = 0.25/v;
				
				switch( maxIndex ){
					case 0: //x
						*pq[1] = (R[3] + R[1]) * mult;
						*pq[2] = (R[2] + R[6]) * mult;
						*pq[3] = (R[7] - R[5]) * mult;
						break;

					case 1: //y
						*pq[0] = (R[3] + R[1]) * mult;
						*pq[2] = (R[7] + R[5]) * mult;
						*pq[3] = (R[2] - R[6]) * mult;
						break;

					case 2: //z
						*pq[0] = (R[2] + R[6]) * mult;
						*pq[1] = (R[7] + R[5]) * mult;
						*pq[3] = (R[3] - R[1]) * mult;
						break;
						
					case 3: //t
						*pq[0] = (R[7] - R[5]) * mult;
						*pq[1] = (R[2] - R[6]) * mult;
						*pq[2] = (R[3] - R[1]) * mult;
						break;
				}
				return *this;
			}


			// this function converts rotation vector to quaternion.
			// quaternion is stored in this class.
			// @param vec[3]: rotation vector
			//        rad: rotation angle in radian
			// @return quaternion
			inline Quaternion& convRotVec2Quat(double vec[3], double rad){
				double n(vec[0]*vec[0]+vec[1]*vec[1]+vec[2]*vec[2]);
				if(n <= 0.0){
					this->w=0.0; this->x=0.0;
					this->y=0.0; this->z=0.0;
					return *this;
				}
				n = 1.0/sqrt(n);
				double nvec[3]={vec[0]*n, vec[1]*n, vec[2]*n};
				rad*=0.5;
				double s(sin(rad));

				this->w = cos(rad); this->x=nvec[0]*s;
				this->y=nvec[1]*s; this->z=nvec[2]*s;
				
				return *this;
			}

			inline void transVector(double dstvec[3], double srcvec[3]){
				Quaternion q(0.0, dstvec[0], dstvec[1], dstvec[2]);
				q = *this * q;
				dstvec[0] = q.x; dstvec[1] = q.y; dstvec[2] = q.z;
			}

			// this function generate rotation matrix from this quaternion.
			// @param R[9]: rotarion matrix
			inline void convQuat2RotMat(double R[9]){
				double s(norm()); s = 2.0 / (s*s);
				double vx(x*s), vy(y*s), vz(z*s);
				double wx(w*vx), wy(w*vy), wz(w*vz);
				double sx(x*vx), sy(y*vy), sz(z*vz);
				double cx(y*vz), cy(z*vx), cz(x*vy);

				R[0] = 1.0 - sy - sz;
				R[3] = cz + wz;
				R[6] = cy - wy;

				R[1] = cz - wz;
				R[4] = 1.0 - sx - sz;
				R[7] = cx + wx;

				R[2] = cy + wy;
				R[5] = cx - wx;
				R[8] = 1.0 - sx - sy;
			}

			inline void convQuat2Mat(double R[9]){
				double sx(x*x), sy(y*y), sz(z*z);
				double cx(y*z), cy(z*x), cz(x*y);
				double wx(w*x), wy(w*y), wz(w*z);

				R[0] = 1.0 - 2.0 * (sy + sz);
				R[3] = 2.0 * (cz + wz);
				R[6] = 2.0 * (cy - wy);

				R[1] = 2.0 * (cz - wz);
				R[4] = 1.0 - 2.0 * (sx + sz);
				R[7] = 2.0 * (cx + wx);

				R[2] = 2.0 * (cy + wy);
				R[5] = 2.0 * (cx - wx);
				R[8] = 1.0 - 2.0 * (sx + sy);
			}
           
			// this function provides 'spherical linear interpolation'.
			// this generates quaternion to interpolate between this quaternion and target quaternion.
			// @param q: target quaternion
			//        d: parameter [0.0 - 1.0]
			inline Quaternion slerp(const Quaternion &q, double d){
				Quaternion retq;
				double qr(w*q.w + x*q.x + y*q.y + z*q.z);
				double ss(1.0 - qr*qr);
				if(ss == 0.0){
					retq=*this;
					return retq;
				}else{
					double ph(acos(qr));
					if(qr < 0.0 && ph > M_PI * 0.5){
						qr *= -1.0;
						ph = acos(qr);
						double s1( sin(ph*(1.0-d))/sin(ph) );
						double s2( sin(ph*d)/sin(ph) );
						retq.x = x*s1 - q.x*s2;
						retq.y = y*s1 - q.y*s2;
						retq.z = z*s1 -	q.z*s2;
						retq.w = w*s1 - q.w*s2;
						return retq;
					}else{
						double s1( sin(ph*(1.0-d))/sin(ph) );
						double s2( sin(ph*d)/sin(ph));
						retq.x = x*s1 + q.x*s2;
						retq.y = y*s1 + q.y*s2;
						retq.z = z*s1 +	q.z*s2;
						retq.w = w*s1 + q.w*s2;
						return retq;
					}
				}
				return retq;
			}

			// normalize quaternion
			inline void normalize(){
				*this/=norm();
			}

			// calculate norm of quaternion
			inline double norm(){
				return sqrt(w*w + x*x + y*y + z*z);
			}

			private:
			inline double sign(double x){return (x >= 0.0f) ? +1.0f : -1.0f;}
		};
	}; //namespace UTIL_MAT
}; //namespace ALTH

#endif // _ROT_MARGE_H_