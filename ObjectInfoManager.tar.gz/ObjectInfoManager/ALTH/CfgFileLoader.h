#ifndef _CFG_FILE_LOADER_H_
#define _CFG_FILE_LOADER_H_

#include <iostream>
#include <string>
#include <vector>
#include <sstream>
#include <algorithm>
#include <fstream>
#include <stdexcept>

using namespace std;

//
// CfgFileLoader.h
//
// @brief This functions are used to read configuration file
// @author H.Takahashi, Osaka Univ.
// @last modified in Aug. 2009
//

namespace ALTH{
	namespace Cfg{
		//==============================================
		// split function
		//
		// @brief split string with delimiter
		// @param str   : string data
		//        delim : delimiter
		// @return vector<string> : splited string data 
		//==============================================
		vector<string> split(string str, string delim);

		//==============================================
		// CfgFileLoader class
		//
		// @brief load configuration file
		// @constructor<T> : T is parameter's format
		//==============================================
		template <class T>
		class CfgFileLoader
		{
			//=====================================
			// CfgComParam
			// @brief data class
			//=====================================
			class CfgComParam{
			private:
				// command
				string _com;
				// parameter
				vector<T> _param;
				// maximum number of parameter
				int _paramNum;

			public:
				// constructor
				CfgComParam(){}
				CfgComParam(string com, int num){ setCommand(com, num); }

				// set command
				// @param &com: command
				//         num: maximum number of parameter
				inline void setCommand(string &com){ _com = com;}
				inline void setCommand(string &com, int num){ _com = com; _paramNum = num;}
				// get command
				inline string getCommand(){return _com;}

				// set parameter
				void setParameter(vector<T> param){ _param = param;}
				// get parameter
				vector<T> getParameter(){return _param;}
				// get maximum number of parameter
				inline int getNumParameter(){return _paramNum;}
			};

		public:
			// constractor
			CfgFileLoader();
			// @param filename: file name
			CfgFileLoader(string filename);

			// destructor
			~CfgFileLoader();

		private:
			// configuration command and parameter's list
			vector<CfgComParam> _list_CfgComParam;
			// number of list
			int _cfgComParamNum;

			// configuration file name
			string _filename;

			// delimiter for comment
			char _delim_com;
			// delimiter to separate string to parameter and command
			char _delim_com_para;
			// delimiter for parameter
			char _delim_para;

		private:
			// remove comment from string
			// @param str: string data
			void removeComment(string &str);

			// load one line command
			// @brief this function reads parameter on command list
			// @param str: string data
			void loadCommandLine(string &str);

		public:
			// set comment's delimiter
			// @param delim: delimiter
			void setCommentDelimiter(const char delim){_delim_com=delim;}

			// set delimiter to separate string to comand and parameter
			// @param delim: delimiter
			void setCPDelimiter(const char delim){_delim_com_para=delim;}

			// set parameter's delimiter
			void setPrameterDelimiter(const char delim){_delim_para=delim;}

			// set configuration file name
			// @param name: file's name
			void setFileName(const string name){_filename=name;}

			// set new command
			// @brief this function adds new command to list
			bool setNewCommand(const string com, int num);

			// delete all command
			bool deleteAllCommand();

			// load file
			// @param filename: configuration file's name
			bool loadCfgFile();
			bool loadCfgFile(string filename);

			// get paramter
			// @param command: configuration command
			// @exception if command is not in command list, exception is throwed.
			vector<T> getParameter(string command)
				throw(std::invalid_argument);
		};
	}; // namespace Cfg
}; // namespace ALTH
//-----------------------------------------------------------------------------------------
//implimentation of template class "CfgFileLoader"

namespace ALTH{
	// constractor
	template <class T>
	Cfg::CfgFileLoader<T>::CfgFileLoader()
	:_cfgComParamNum(0)
	{
		setCommentDelimiter('#');
		setCPDelimiter(':');
		setPrameterDelimiter(',');
	}
	template <class T>
	Cfg::CfgFileLoader<T>::CfgFileLoader(string filename)
	:_cfgComParamNum(0)
	{
		setCommentDelimiter('#');
		setCPDelimiter(':');
		setPrameterDelimiter(',');
		setFileName(filename);
	}

	// destructor
	template <class T>
	Cfg::CfgFileLoader<T>::~CfgFileLoader()
	{
		deleteAllCommand();
	}


	// remove comment from string
	// @param str: string data
	template<class T>
	void Cfg::CfgFileLoader<T>::removeComment(string &str)
	{
		int com_index = str.find(string(&_delim_com,1));
		if (com_index != string::npos){
			str = str.substr(0, com_index);
		}
	}

	// load one line command
	// @brief this function reads parameter on command list
	// @param str: string data
	template<class T>
	void Cfg::CfgFileLoader<T>::loadCommandLine(string &str)
	{
		// remove comment
		removeComment(str);

		// convert parameter's delimiter to ' '
		std::replace( str.begin(), str.end(), _delim_para, ' ');

		// separate string to command and parameter
		vector<string> vecstr = split(str, string(&_delim_com_para,1));
		
		// remove ' ' of the both ends of string
		for(int i=0; i<vecstr.size(); ++i){
			if(!vecstr[i].empty()){
				vecstr[i] = vecstr[i].substr(0, vecstr[i].find_last_not_of(' ')+1);
			}
			if(!vecstr[i].empty()){
				vecstr[i] = vecstr[i].substr(vecstr[i].find_first_not_of(' '));
			}
		}

		// search command
		for (int i=0; i<_cfgComParamNum; ++i){
			if(vecstr[0] == _list_CfgComParam[i].getCommand() && !vecstr[1].empty()){//command exists
				// convert parameter's string to parameter's type
				std::istringstream iss(vecstr[1]);
				int num=_list_CfgComParam[i].getNumParameter();
				vector<T> vecParam;
				while(!iss.eof()){
					T param;
					iss >> param;
					vecParam.push_back(param);
				}
				// set parameter
				_list_CfgComParam[i].setParameter(vecParam);
			}
		}
	}

	// set new command
	// @brief this function adds new command to list
	template<class T>
	bool Cfg::CfgFileLoader<T>::setNewCommand(const string com, int num){

		if(_cfgComParamNum != 0) {// list is not empty
			// chack command
			// Is this command already existed?
			for(int i=0; i<_cfgComParamNum; ++i){
				if(_list_CfgComParam[i].getCommand() == com){ // this command has already existed
					return false;
				}
			}
		}

		// add new command
		_list_CfgComParam.push_back(CfgComParam(com, num));
		++_cfgComParamNum;
		return true;
	}

	// delete all command
	template<class T>
	bool Cfg::CfgFileLoader<T>::deleteAllCommand(){
		_list_CfgComParam.clear();
		_cfgComParamNum = 0;

		return true;
	}

	// load file
	// @param filename: configuration file's name
	template<class T>
	bool Cfg::CfgFileLoader<T>::loadCfgFile(){
		string filebuf;// file string's buffer
		ifstream ifs(_filename.c_str());// file stream

		if(ifs.fail()){
			return false;
		}

		//read file
		while(ifs && getline(ifs, filebuf)){
			// set parameter
			loadCommandLine(filebuf);
		}
		return true;
	}
	template<class T>
	bool Cfg::CfgFileLoader<T>::loadCfgFile(string filename){
		setFileName(filename);
		return loadCfgFile();
	}

	// get paramter
	template<class T>
	vector<T> Cfg::CfgFileLoader<T>::getParameter(string command)
	throw(std::invalid_argument)
	{
		// search command
		for (int i=0; i<_cfgComParamNum; ++i){
			if(command == _list_CfgComParam[i].getCommand()){//command exists
				// convert parameter's string to parameter's type
				return _list_CfgComParam[i].getParameter();
			}
		}

		// exception
		throw std::invalid_argument("exception! CfgFileLoader::getParameter() invalid command");
	}
}; //namespace ALTH
#endif //_CFG_FILE_LOADER_H_