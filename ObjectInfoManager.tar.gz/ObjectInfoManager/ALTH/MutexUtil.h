#ifndef _MUTEX_UTIL_H_
#define _MUTEX_UTIL_H_

//
// MutexUtil.h
//
// @brief this header file provides 'mutex' function.
//        current version supports only windows OS.
//
// @author H.Takahashi, Osaka Univ.
// @last modifed in Oct, 2009
//

// windows version
#ifdef WIN32
#include <winsock.h>
#include <windows.h>

namespace ALTH {
	namespace UTIL{

		typedef HANDLE pthread_mutex_t;

		class Mutex {
		private:
			// prohibit copying and substituting 
			Mutex(const Mutex&);
			Mutex& operator=(const Mutex&);

		public:
			pthread_mutex_t _mutex;

			Mutex(){
				_mutex = ::CreateMutex(NULL, FALSE, NULL);
			}
			~Mutex(){
				::CloseHandle(_mutex);
			}

			// lock function
			inline void lock(){
				::WaitForSingleObject(_mutex, INFINITE);
			}

			// unlock function
			inline void unlock(){
				::ReleaseMutex(_mutex);
			}

		};
	}; // namespace UTIL
}; // namespace ALTH
#endif //WIN32
#endif //_MUTEX_UTIL_H_