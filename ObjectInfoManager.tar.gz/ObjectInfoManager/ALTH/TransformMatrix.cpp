#include "TransformMatrix.h"

namespace ALTH{
namespace TC{

// get label
char* getLabel(trans_t type){
	switch(type){
		case TRANS_ERROR: return"TRANS_ERROR";
		case TRANS_HOMOGENEOUS: return "TRANS_HOMOGENEOUS";
		case TRANS_HOMOGENEOUS_R_T: return "TRANS_HOMOGENEOUS_R_T";
		case TRANS_XYZ_ROLL_PITCH_YAW: return "TRANS_XYZ_ROLL_PITCH_YAW";
	}
	return "TRANS_ERROR";
}
// 
// @param str: transformation type
trans_t transLabel2Enum(const char* str){
	std::string strType(str);
	if(strType == "TRANS_HOMOGENEOUS"){
		return TRANS_HOMOGENEOUS;
	}else if(strType == "TRANS_HOMOGENEOUS_R_T"){
		return TRANS_HOMOGENEOUS_R_T;
	}else if(strType == "TRANS_XYZ_ROLL_PITCH_YAW"){
		return TRANS_XYZ_ROLL_PITCH_YAW;
	}
	return TRANS_ERROR;
}

//================ implement of TransformMatrix ========================
// constructor
TransformMatrix::TransformMatrix()
:_inTransType(TRANS_HOMOGENEOUS), _outTransType(TRANS_HOMOGENEOUS)
{
	G3M_SET(_tR, 1.0,0.0,0.0, 0.0,1.0,0.0, 0.0,0.0,1.0);
	G3V_SET(_tT, 0.0,0.0,0.0);
}
// constructor
TransformMatrix::TransformMatrix(trans_t itype, trans_t otype)
:_inTransType(itype), _outTransType(otype)
{
	G3M_SET(_tR, 1.0,0.0,0.0, 0.0,1.0,0.0, 0.0,0.0,1.0);
	G3V_SET(_tT, 0.0,0.0,0.0);
}

// destructor
TransformMatrix::~TransformMatrix(){
	;
}

// set transform type
void TransformMatrix::setTransType(trans_t itype, trans_t otype){
	_inTransType = itype;
	_outTransType = otype;
}
void TransformMatrix::setTransType(const char* itype, const char* otype){
	_inTransType = transLabel2Enum(itype);
	_outTransType = transLabel2Enum(otype);
}

// set transform matrix
// @param tR : rotation matrix [3*3]
//        tT : translation matrix [3*1]
void TransformMatrix::setTransMat(double tR[], double tT[]){
	memcpy(_tR, tR, sizeof(double)*9);
	memcpy(_tT, tT, sizeof(double)*3);
}

// @param tH : homogeneous matrix [3*4]
void TransformMatrix::setTransMat(double tH[]){
	_tR[0]=tH[0];_tR[1]=tH[1];_tR[2]=tH[2];_tT[0]=tH[3];
	_tR[3]=tH[4];_tR[4]=tH[5];_tR[5]=tH[6];_tT[1]=tH[7];
	_tR[6]=tH[8];_tR[7]=tH[9];_tR[8]=tH[10];_tT[2]=tH[11];
}

// transform matrix
// @param value : input matrix	
void TransformMatrix::calculateTransformMatrix(double inmt[] , double  outmt[]){
	// buffer handle matrix
	double *iR;
	double *iT;
	double *oR=&outmt[0];
	double *oT=&outmt[9];

	// set input matrix data is set into "iR" and "iT"
	if(_inTransType == TRANS_HOMOGENEOUS){
		iR = new double[9];
		iT = new double[3];
		G3M_SET(iR, inmt[0],inmt[1],inmt[2],
			        inmt[4],inmt[5],inmt[6],
					inmt[8],inmt[9],inmt[10]);
		G3V_SET(iT, inmt[3],inmt[7],inmt[11]);
	}
	else if(_inTransType == TRANS_HOMOGENEOUS_R_T){
		iR=(double*)&inmt[0];
		iT=(double*)&inmt[9];
	}
	else if(_inTransType == TRANS_XYZ_ROLL_PITCH_YAW){
		// this part will be implemeted in near future..
		;
	}
	// // print sorce information
	// std::cout << "\n----- in call back function ----" << std::endl;
	// std::cout << "sorce matrix is" << std::endl;
	// G3M_XFORM_PRINTF(iR, iT);

	// now, input matrix data is set into "iR" and "iT".
	// transform matrix
	G3M_XFORM_MERGE( oR, oT, _tR, _tT, iR, iT);

	// // print dest info
	// std::cout << "\ndest matrix is " << std::endl;
	// G3M_XFORM_PRINTF(oR, oT);
	// std::cout << "-----------------------------------" << std::endl;

	// output data
	if(_outTransType == TRANS_HOMOGENEOUS){
		// convert data
		// | 0  1  2 |    | 0 1 2 9 |
		// | 3  4  5 | => | 3 4 5 10|
		// | 6  7  8 |    | 6 7 8 11|
		// | 9  10 11|
		double temp[12];
		memcpy(temp, &outmt[0], sizeof(double)*12);
		outmt[3]=temp[9];
		outmt[4]=temp[3]; outmt[5]=temp[4]; outmt[6]=temp[5]; outmt[7]=temp[10];
		outmt[8]=temp[6]; outmt[9]=temp[7]; outmt[10]=temp[8];
	}
	else if(_outTransType == TRANS_HOMOGENEOUS_R_T){
		// do nothing
		;
	}
	else if(_outTransType == TRANS_XYZ_ROLL_PITCH_YAW){
		// this part will be implemeted in near future..
		;
	}
	
	// delete buffer
	if(_inTransType == TRANS_HOMOGENEOUS){
		delete [] iR;
		delete [] iT;
	}

}

}; // namespace TC
}; // namespace ALTH

//===================================== test code =====================================
#if 0
#include <iostream>
#include <cmath>
#include "EnonKinematics.hpp"
using namespace ALTH;
using namespace ALTH::TC;
#define DEG2RAD(x) ((x)*M_PI/180.0)
int main()
{
	TC::trans_t tt1 = transLabel2Enum("hoge");
	std::cout << "TransType1 " << getLabel(tt1) << std::endl;
	tt1=TC::TRANS_HOMOGENEOUS;	
	std::cout << "TransType1 " << getLabel(tt1) << std::endl;
	if(tt1 == TC::TRANS_HOMOGENEOUS){
		std::cout << "TransType1 is TRANS_HOMOGENEOUS" << std::endl;
	}else{
		std::cout << "TransType1 is not TRANS_HOMOGENEOUS" << std::endl;
	}

	TC::trans_t tt2(TC::TRANS_HOMOGENEOUS_R_T);
	std::cout << "TransType2 " << getLabel(tt2) << std::endl;
	if(tt2 == TC::TRANS_HOMOGENEOUS_R_T){
		std::cout << "TransType2 is TRANS_HOMOGENEOUS_R_T" << std::endl;
	}else{
		std::cout << "TransType2 is not TRANS_HOMOGENEOUS_R_T" << std::endl;
	}
	tt2 = tt1;
	std::cout << "TransType2 " << getLabel(tt2) << std::endl;
	if(tt2 == TC::TRANS_HOMOGENEOUS){
		std::cout << "TransType2 is TRANS_HOMOGENEOUS" << std::endl;
	}else{
		std::cout << "TransType2 is not TRANS_HOMOGENEOUS" << std::endl;
	}

	TransformMatrix trans;
	RTC::TimedDoubleSeq sMat;
	RTC::TimedDoubleSeq dMat;
	double dR[9]={0.0};
	double dT[3]={0.0};
	double tR[9]={0.0};
	double tT[3]={0.0};
	// create buffer
	sMat.data.length(12);
	// input matrix
	sMat.data[0]=1.0; sMat.data[1]=0.0; sMat.data[2]=0.0; sMat.data[3]=0.0;
	sMat.data[4]=0.0; sMat.data[5]=1.0; sMat.data[6]=0.0; sMat.data[7]=0.0;
	sMat.data[8]=0.0; sMat.data[9]=0.0; sMat.data[10]=1.0; sMat.data[11]=0.0;
	// copy data
	G3M_SET(dR, sMat.data[0], sMat.data[1], sMat.data[2],
		        sMat.data[4], sMat.data[5], sMat.data[6],
				sMat.data[8], sMat.data[9], sMat.data[10]);
	G3V_SET(dT, sMat.data[3], sMat.data[7], sMat.data[11]);
	// print
	std::cout << " 'TransformMatrix' class test" << std::endl;
	std::cout << "input matrix" << std::endl;
	G3M_XFORM_PRINTF(dR, dT);


	// set transformation type
	//  : input->homogeneous matrix
	//  : output->homogeneous matrix
	trans.setTransType(TC::TRANS_HOMOGENEOUS, TC::TRANS_HOMOGENEOUS);
	
	// set transformation matrix
	//  : rotate 45 degree in the z-axis
	//  : translate 1.0 in z direction
	G3M_SET(tR, cos(DEG2RAD(45.0)), -sin(DEG2RAD(45.0)), 0.0,
		        sin(DEG2RAD(45.0)),  cos(DEG2RAD(45.0)), 0.0,
		                       0.0,                 0.0, 1.0 );
	G3V_SET(tT, 0.0, 0.0, 1.0);
	trans.setTransMat(tR, tT);

	// transform coordinate
	dMat = trans(sMat);
	// copy data
	G3M_SET(dR, dMat.data[0], dMat.data[1], dMat.data[2],
		        dMat.data[4], dMat.data[5], dMat.data[6],
				dMat.data[8], dMat.data[9], dMat.data[10]);
	G3V_SET(dT, dMat.data[3], dMat.data[7], dMat.data[11]);
	// print
	std::cout << ": rotate 45 degree in the z-axis\n: translate 1.0 in z direction" << std::endl;
	G3M_XFORM_PRINTF(dR, dT);

	// set transformation matrix
	//  : rotate -45 degree in the z-axis
	//  : translate -1.0 in z direction
	G3M_SET(tR, cos(DEG2RAD(-45.0)), -sin(DEG2RAD(-45.0)), 0.0,
		        sin(DEG2RAD(-45.0)),  cos(DEG2RAD(-45.0)), 0.0,
		                       0.0,                 0.0, 1.0 );
	G3V_SET(tT, 0.0, 0.0, -1.0);

	// set transformation type
	//  : input->homogeneous matrix
	//  : output->[R T]
	trans.setTransType(TC::TRANS_HOMOGENEOUS, TC::TRANS_HOMOGENEOUS_R_T);

	trans.setTransMat(tR, tT);

	dMat=trans(dMat);
	// copy data
	G3M_SET(dR, dMat.data[0], dMat.data[1], dMat.data[2],
		        dMat.data[3], dMat.data[4], dMat.data[5],
				dMat.data[6], dMat.data[7], dMat.data[8]);
	G3V_SET(dT, dMat.data[9], dMat.data[10], dMat.data[11]);
	// print
	std::cout << ": rotate -45 degree in the z-axis\n: translate -1.0 in z direction" << std::endl;
	G3M_XFORM_PRINTF(dR, dT);
	std::cout << "end test\n<Press any key>" << std::ends; 
	getchar();


	std::cout << "----- test with 'EnonKinematics' ----- " << std::endl;
	// initialize;
	EnonKinematics ek; ek.loadRobotInformation();
	TransformMatrix wpt(TC::TRANS_HOMOGENEOUS_R_T, TC::TRANS_HOMOGENEOUS_R_T);

	// update Head pose angle. pan 0.0, tilt 0.0
	//       |z
	//       | )pan
	//       |<_____y) tilt            x______
	//      /       <                        /|
	//   x /                              z / |
	//                                         y
	// robot/neck coordinate            camera coordinate
	
	// set sorce coordinate
	RTC::TimedDoubleSeq src; src.data.length(12);
	G3M_SET((double*)&src.data[0], 1.0, 0.0, 0.0,
		                           0.0, 1.0, 0.0,
								   0.0, 0.0, 1.0);
	G3V_SET((double*)&src.data[9], 0.5, 0.5, 1.0);
	double pantilt[4][2]={{0.0, 0.0}, {45.0, 0.0}, {-45.0, 0.0}, {0.0, 45.0}};
	std::cout << "src" << std::endl;
	G3M_XFORM_PRINTF((double*)&src.data[0], (double*)&src.data[9]);

	for(int i=0; i<4; ++i){
		// update pan-tilt angle[deg]
		ek.updateHeadPose(pantilt[i][0], pantilt[i][1]);
		std::cout << "transform matrix" << std::endl;
		G3M_XFORM_PRINTF(ek.Rrc, ek.Trc);

		// set transform matrix
		wpt.setTransMat( ek.Rrc , ek.Trc);

		RTC::TimedDoubleSeq dst = wpt(src);

		// print dst matrix
		std::cout << "dst matrix" << std::endl;
		G3M_XFORM_PRINTF((double*)&dst.data[0], (double*)&dst.data[9]);
		std::cout << std::endl;
	}
	std::cout << "<PushAnyKey>" << std::ends;

	getchar();
	return 0;
}
#endif
//================================= end of test code ==================================
