#include "imagecaptureWebIEEE1394Cam.h"

namespace ALTH{

// constructor
WebIEEE1394Cam::WebIEEE1394Cam():
_webcam(NULL), _ieee1394cam(NULL)
{
}

// constructor
WebIEEE1394Cam::WebIEEE1394Cam(bool camera, bool stereo):
_webcam(NULL), _ieee1394cam(NULL)
{
	// instance capture class
	setCaptureCamera(camera);
	if (_captureCamera){
		(*this)._webcam = new WebCam();
	} else {
		_ieee1394cam = new IEEE1394Cam();
		_ieee1394cam->setStereo(stereo);
	}
}

// destructor
WebIEEE1394Cam::~WebIEEE1394Cam() {
	Closes();
}

// open camera
bool WebIEEE1394Cam::Opens(){
	if (_captureCamera){
		if (_webcam != NULL){
			return _webcam->Opens();
		}
	} else {
		if(_ieee1394cam != NULL){
			return _ieee1394cam->Opens();
		}
	}
	return false;
}

// open camera
// @param
//   camera : web/IEEE1394
//   stereo : stereo/single
bool WebIEEE1394Cam::Opens(bool camera, bool stereo){
	// instance capture class
	setCaptureCamera(camera);
	if (_captureCamera){
		if (_webcam == NULL){
			_webcam = new WebCam();
		}
		return _webcam->Opens();
	} else {
		if (_ieee1394cam == NULL){
			_ieee1394cam = new IEEE1394Cam();
		}
		return _ieee1394cam->Opens(stereo);
	}
	return false;
}

// close camera
bool WebIEEE1394Cam::Closes(){
	bool flag(false);
	// delete capture class
	if (_webcam != NULL){
		flag = _webcam->Closes();
		if (flag){
			delete _webcam;
			_webcam = NULL;
		}
	}
	if (_ieee1394cam != NULL){
		flag = _ieee1394cam->Closes();
		if (flag){
			delete _ieee1394cam;
			_ieee1394cam = NULL;
		}
	}
	return flag;
}


// capture image
// @param
//  unsigned char* buffer : image buffer
bool WebIEEE1394Cam::CaptureImages(unsigned char* buffer){
	if (_captureCamera){
		return _webcam->CaptureImages(buffer);
	}else{
		return _ieee1394cam->CaptureImages(buffer);
	}
	return false;
}

// capture image
// @param
//  bufferL : image buffer of Left Camera
//  bufferR : image buffer of Right Camera
bool WebIEEE1394Cam::CaptureImages(unsigned char* bufferL, unsigned char*bufferR){
	if(_captureCamera){
		return false;
	}else{
		return _ieee1394cam->CaptureImages(bufferL, bufferR);
	}
	return false;
}


// @param
//    stereo(for bumblebee): "true/false", true:both, false:right
//                         : monocular camera:"false"
bool WebIEEE1394Cam::setStereo(bool stereo){
	if (_ieee1394cam != NULL){
		return _ieee1394cam->setStereo(stereo);
	}
	return false;
}
bool WebIEEE1394Cam::getStereo(){
	if (_ieee1394cam != NULL){
		return _ieee1394cam->getStereo();
	}
	return false;
}

// @param
//     camera: true(web camera), false(firewire camera)
void WebIEEE1394Cam::setCaptureCamera(bool camera){
	_captureCamera = camera;
}

bool WebIEEE1394Cam::getCaptureCamera(){
	return _captureCamera;
}

// image size
// @param
//  w : image's width
//  h : image's height
void WebIEEE1394Cam::setImageSize(int w, int h){
	if(_webcam!=NULL){
		_webcam->setImageSize(w,h);
	}
	if(_ieee1394cam!=NULL){
		_ieee1394cam->setImageSize(w,h);
	}
}
void WebIEEE1394Cam::getImageSize(int* w, int* h){
	if(_webcam!=NULL){
		_webcam->getImageSize(w,h);
	}
	if(_ieee1394cam!=NULL){
		_ieee1394cam->getImageSize(w,h);
	}
}

// pixeltype
// @pixel type                        @number
//  PIXEL_GRAY   (1 channels/pixel)      1
//  PIXEL_GRAYA  (2 channels/pixel)      2
//  PIXEL_RGB    (3 channels/pixel)      3
//  PIXEL_RGBA   (4 channels/pixel)      4
//  PIXEL_BGR    (3 channels/pixel)      5
//  PIXEL_YUV    (3 channels/pixel)      6
pixel_t WebIEEE1394Cam::getPixelType(){
	if(_webcam!=NULL){
		return _webcam->getPixelType();
	}
	if(_ieee1394cam!=NULL){
		return _ieee1394cam->getPixelType();
	}
	return PIXEL_UNKNOWN;
}
void WebIEEE1394Cam::setPixelType(pixel_t ptype){
	if(_webcam!=NULL){
		_webcam->setPixelType(ptype);
	}
	if(_ieee1394cam!=NULL){
		_ieee1394cam->setPixelType(ptype);
	}
}

bool WebIEEE1394Cam::getActivated(){
	if(_webcam!=NULL){
		return _webcam->getActivated();
	}
	if(_ieee1394cam!=NULL){
		return _ieee1394cam->getActivated();
	}
	return false;
}


}; // namespace ALTH