#include "imagecaptureWebCam.h"

namespace ALTH{

// constructor
WebCam::WebCam():
_image(NULL)
{
}

// destructor
WebCam::~WebCam() {
	if (_activated){
		Closes();
	}
}
//======================================================================================
// implimetation of functions for Web camera
//======================================================================================
// open web camera
bool WebCam::Opens(){
	// Obtaining CvCapture Handler
	_capture = cvCreateCameraCapture(CV_CAP_ANY);
	if(_capture == 0){
		std::cout<<"Cannot obtain CvCapture handler"<<std::endl;
		return false;
	}

	// Image capture for obtained image information
	_image = cvQueryFrame(_capture);

	// Copy image information
	_width	= _image->width;
	_height	= _image->height;
	_pixel_size = _image->nChannels;
	_row_size = _width*_pixel_size;

	_activated = true;
	return true;
}

// close web camra
bool WebCam::Closes(){
	// Release CvCapture handler
	cvReleaseCapture(&_capture);

	_activated = false;
	return true;
}

// capture image by web camera
bool WebCam::CaptureImages(unsigned char* buffer){
	if (!_activated){return false;}

	// capture image
	_image = cvQueryFrame(_capture);
	// copy image buffer to "buffer"
	memcpy(buffer, _image->imageData, _image->imageSize);

	if (_ptype == PIXEL_RGB){
		// convert BGR->RGB
		unsigned char hoge;
		unsigned char *src = buffer;
		unsigned char *dst = buffer;
		for (int y=0; y<_height; ++y){
			for (int x=0; x<_width; ++x){
				hoge = src[0];
				src[0] = dst[2];
				dst[2] = hoge;

				src += 3; dst+=3;
			}
		}
		return true;
	}

	return true;
}

}; //namespace ALTH
//===================================== test code =====================================
#if 0
#include <iostream>
#include "ImageViewer.h"
using namespace ALTH;
int main(){
	WebCam ic;
	ImageViewer iv;

	ic.setPixelType(ALTH::PIXEL_BGR);
	ic.Opens();
	int w, h;
	ic.getImageSize(&w, &h);
	unsigned char *buf = new unsigned char[w*h*3];
	iv.openWindow("test window", w, h);
	for(int i=0; i<100; ++i){
		ic.CaptureImages(buf);
		iv.showImage(buf);
	}
	ic.Closes();
	iv.closeWindow();

	return 0;
}
#endif
//================================= end of test code ==================================