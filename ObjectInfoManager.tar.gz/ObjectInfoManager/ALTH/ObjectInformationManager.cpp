#include "ObjectInformationManager.h"

// include OpenCV
#include <cv.h>
//#include <cxcore.h>
#include <highgui.h>
#include <string>

namespace ALTH{
//
// tools to draw objects poses on X-Y coordinate
//
	//-----------------------------------------------
	// definition of color
#define COLOR_BLACK CV_RGB(0, 0, 0)
#define COLOR_RED   CV_RGB(255, 0, 0)
#define COLOR_GREEN CV_RGB(0, 255, 0)
#define COLOR_BLUE  CV_RGB(0, 0, 255)
	//-----------------------------------------------
	// converter
	// scale: 1[pixel]->1.0/100.0[m]
	const double SCALE_PIXEL2METER = 0.005;
	const double SCALE_METER2PIXEL = 200.0;

	// @param p : a value[pixel] on image coordinate
	// @return a value[m] on real coordinate
	inline double PIXEL2METER(double p){
		return SCALE_PIXEL2METER*p;
	}

	// @param m : a value[m] on real coordinate
	// @return a value[pixel] on image coordinate
	inline double METER2PIXEL(double m){
		return SCALE_METER2PIXEL*m;
	}

	// image size
	const int DISP_HEIGHT(480);
	const int DISP_WIDTH(640);

	//
	// (0,0)-----                    |
	// | (w/2,h/2)       ----------(0,0)---------
	// |     (w-1,h-1)               |
	//                   (-w/2,-h/2)
	inline double IMGX2DRAWIMGX(double x){
		double hw(DISP_WIDTH/2);
		if(x<0){x-=0.5;}
		else{x+=0.5;}
		x=x+hw;
		return x;
	}
	inline double IMGY2DRAWIMGY(double y){
		double hh(DISP_HEIGHT/2);
		if(y<0){y-=0.5;}
		else{y+=0.5;}
		y=-y+hh;
		return y;
	}
	//------------------------------------------------

//=================== implementation of "ObjectInformation" ============================
// copy constructor
ObjectInformation::ObjectInformation(const ObjectInformation& obj){
	// copy all data
	memcpy((*this)._R, obj._R, sizeof(double)*9);
	memcpy((*this)._T, obj._T, sizeof(double)*3);
	_key = obj._key;
	_tm = obj._tm;
}

// assignment operator overload
ObjectInformation &ObjectInformation::operator=(const ObjectInformation &obj){
	// copy all data
	memcpy((*this)._R, obj._R, sizeof(double)*9);
	memcpy((*this)._T, obj._T, sizeof(double)*3);
	_key = obj._key;
	_tm = obj._tm;

	return (*this);
}

//===================== implementation of "ObjectInformationManager" ==================
// constructor
ObjectInformationManager::ObjectInformationManager():_dispbuf(NULL){
}

// destructor
ObjectInformationManager::~ObjectInformationManager(){
	_iv.closeWindow();
}

// query object information with key
// @param key : key of object
// @return object information
bool ObjectInformationManager::queryObjectInfo(std::string key, ObjectInformation &obj)const
{
	std::list<ObjectInformation>::const_iterator it = _objList.begin();

	while(it != _objList.end()){
		if((*it).getKey() == key){
			// same key is exist
			obj = (*it);
			return true;
		}
		++it;
	}

	// object is not found
	return false;
}

// register object information
// @param obj : object information
void ObjectInformationManager::registerObjectInfo(const ObjectInformation& obj){
	std::list<ObjectInformation>::iterator it = _objList.begin();

	while(it != _objList.end()){
		if(it->getKey() == obj.getKey()){
			// now, same key is exist.
			// copying object's value
			(*it) = obj;
			return;
		}
		++it;
	}

	// same key is not exist
	// add value into list
	_objList.push_back(obj);
}

// delete object information
void ObjectInformationManager::deleteAllObjectInfo(){
	_objList.clear();
}

void ObjectInformationManager::deleteObjectInfo(std::string key){
	ObjectInformation obj;
	obj.setKey(key);
	_objList.remove(obj);
}


// display object information
bool ObjectInformationManager::displayObjectInfo(){
	// open display window
	int dw(DISP_WIDTH), dh(DISP_HEIGHT); // window size
	_iv.openWindow("ObjectPose", dw, dh);

	// allocate buffer
	if(_dispbuf == 0){
		_dispbuf = new unsigned char[dw*dh*3];
	}
	// ready to use opencv function
	IplImage cvdisp; int channels(3); int depth(IPL_DEPTH_8U);
	cvInitImageHeader( &cvdisp, cvSize(dw, dh), depth, channels, IPL_ORIGIN_TL, 4);
	cvdisp.imageData = (char*)_dispbuf;
	CvFont dfont;
	cvInitFont(&dfont, CV_FONT_HERSHEY_PLAIN, 1.0f, 1.0f);
	char str[125];

	// clear image
	cvSet(&cvdisp, cvScalar(255.0, 255.0, 255.0));

	// draw image
	// axis-line of coordinate
	cvDrawLine( &cvdisp, cvPoint(dw/2, 0), cvPoint(dw/2, dh-1), COLOR_BLACK);
	cvDrawLine( &cvdisp, cvPoint(0, dh/2), cvPoint(dw-1, dh/2), COLOR_BLACK);
	cvPutText( &cvdisp, "y", cvPoint(dw/2-10, 10), &dfont, COLOR_BLACK);
	cvPutText( &cvdisp, "x", cvPoint(dw-10, dh/2+10), &dfont, COLOR_BLACK);
	for(double m=-1.5; m<1.5; m+=0.25){
		int dot(METER2PIXEL(m)+0.5);
		int len(2);
		cvDrawLine( &cvdisp, cvPoint(IMGX2DRAWIMGX(dot), IMGY2DRAWIMGY(-len)), cvPoint(IMGX2DRAWIMGX(dot), IMGY2DRAWIMGY(len)), COLOR_BLACK);
		cvDrawLine( &cvdisp, cvPoint(IMGX2DRAWIMGX(-len), IMGY2DRAWIMGY(dot)), cvPoint(IMGX2DRAWIMGX(len), IMGY2DRAWIMGY(dot)), COLOR_BLACK);
		if(abs(m)==0.0||abs(m)==0.5||abs(m)==1.0||abs(m)==1.5||abs(m)==2.0){
			sprintf(str,"%1.1lf", m);
			cvPutText(&cvdisp, str, cvPoint(IMGX2DRAWIMGX(0.0), IMGY2DRAWIMGY(dot)), &dfont, COLOR_BLACK);
			cvPutText(&cvdisp, str, cvPoint(IMGX2DRAWIMGX(dot), IMGY2DRAWIMGY(0.0)), &dfont, COLOR_BLACK);
		}
	}
	// robot body
	cvDrawCircle(&cvdisp, cvPoint(dw/2, dh/2), METER2PIXEL(0.25)+0.5, COLOR_RED);
	cvDrawLine( &cvdisp, cvPoint(dw/2+METER2PIXEL(0.16)+0.5, dh/2), cvPoint(dw/2+METER2PIXEL(0.32)+0.5, dh/2), COLOR_RED, 3);

	// objects
	std::list<ObjectInformation>::const_iterator it = _objList.begin();
	while(it != _objList.end()){
		double R[9], T[3], ic[2];
		double X[3], Y[3];
		// get object pose
		(*it).getPose(R, T);
		X[0]=R[0]; X[1]=R[3]; X[2]=R[6];
		Y[0]=R[1]; Y[1]=R[4]; Y[2]=R[7];
		double xtheta= atan2(X[1], X[0]);
		double ytheta= atan2(Y[1], Y[0]);

		// origin of object on image
		ic[0] = METER2PIXEL(T[0]); ic[1] = METER2PIXEL(T[1]);

		double axislen(30.0);
		// drawing x-axis
		cvDrawLine( &cvdisp, cvPoint(IMGX2DRAWIMGX(ic[0]), IMGY2DRAWIMGY(ic[1])),
			                 cvPoint(IMGX2DRAWIMGX(ic[0]+axislen*cos(xtheta)), IMGY2DRAWIMGY(ic[1]+axislen*sin(xtheta))),
							 COLOR_RED);
		// drawing y-axis
		cvDrawLine( &cvdisp, cvPoint(IMGX2DRAWIMGX(ic[0]), IMGY2DRAWIMGY(ic[1])),
			                 cvPoint(IMGX2DRAWIMGX(ic[0]+axislen*cos(ytheta)), IMGY2DRAWIMGY(ic[1]+axislen*sin(ytheta))),
							 COLOR_GREEN);
		// drawing object id
		sprintf(str, "%s:(%1.3lf,%1.3lf,%1.3lf)", (*it).getKey().c_str(), T[0], T[1], T[2]);
		cvPutText( &cvdisp, str, cvPoint(IMGX2DRAWIMGX(ic[0]), IMGY2DRAWIMGY(ic[1])), &dfont, COLOR_BLUE );

		// next object
		++it;
	}
	
	// show image
	_iv.showImage(_dispbuf);
	return true;
}

bool ObjectInformationManager::closeDisplayWindow(){
	return _iv.closeWindow();
}

}; // namespace ALTH


//===================================== test code =====================================
#if 0
#include <iostream>
using namespace ALTH;
int main()
{
	std::cout << "ObjectInformation class test" << std::endl;
	ObjectInformationManager oim;
	ObjectInformation oi;
	double H[12]={1.0, 0.0, 0.0, 1.0,
		          0.0, 1.0, 0.0, 1.0,
	              0.0, 0.0, 1.0, 1.0 };
	ObjectInformation oi2(H, "hoge");
	oi2.printAllInfomation();
	oi.setInformation("crunky", H);
	oim.registerObjectInfo(oi);
	std::cout << "register object information->crunky" << std::endl;
	oi.printAllInfomation();

	H[0]=0.0;H[1]=0.0;H[2]=1.0;H[3]=-1.0;
	H[4]=0.0;H[5]=1.0;H[6]=0.0;H[7]=0.0;
	H[8]=1.0;H[9]=0.0;H[10]=0.0;H[11]=1.0;
	oi.setInformation("tea_bottle", H);
	oim.registerObjectInfo(oi);
	std::cout << "register object information->tea_bottle" << std::endl;
	oi.printAllInfomation();

	H[0]=0.0;H[1]=0.0;H[2]=1.0;H[3]=-1.0;
	H[4]=0.0;H[5]=1.0;H[6]=0.0;H[7]=1.0;
	H[8]=1.0;H[9]=0.0;H[10]=0.0;H[11]=1.0;
	oi.setInformation("tea_bottle", H);
	oim.registerObjectInfo(oi);
	std::cout << "register object information->tea_bottle" << std::endl;
	oi.printAllInfomation();

	std::cout << "query object information->tea_bottle" << std::endl;
	if(oim.queryObjectInfo("tea_bottle", oi)){oi.printAllInfomation();}
	else{std::cout << "false" << std::endl;}

	std::cout << "query object information->crunky" << std::endl;
	if(oim.queryObjectInfo("crunky", oi)){oi.printAllInfomation();}
	else{std::cout << "false" << std::endl;}

	std::cout << "query object information->hoge" << std::endl;
	if(oim.queryObjectInfo("hoge", oi)){oi.printAllInfomation();}
	else{std::cout << "false" << std::endl;}

	std::cout << "end test" << std::endl;
	std::cout << "<Press any key>" << std::ends;
	getchar();
	return 0;
}
#endif
//================================= end of test code ==================================