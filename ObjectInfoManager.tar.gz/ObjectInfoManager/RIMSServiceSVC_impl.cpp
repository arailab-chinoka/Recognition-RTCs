// -*-C++-*-
/*!
 * @file  RIMSServiceSVC_impl.cpp
 * @brief Service implementation code of RIMSService.idl
 *
 */

#include "RIMSServiceSVC_impl.h"

/*
 * Example implementational code for IDL interface RIMSService
 */
RIMSServiceSVC_impl::RIMSServiceSVC_impl()
{
  // Please add extra constructor code here.
  _mode = "None";
  
  
}


RIMSServiceSVC_impl::~RIMSServiceSVC_impl()
{
  // Please add extra destructor code here.
}


/*
 * Methods corresponding to IDL attributes and operations
 */
CORBA::Boolean RIMSServiceSVC_impl::getObjectPose(const char* obj, RIMSService::ObjectPose pose)
{
  std::cout << "Function called  getObjectPose() " << std::endl;

  // set recognition mode 
  _mode = "get";
  notGetResult();
  
  while(_objInfoFlag){
    //usleep(10);
  }
  
  //set key
  std::string sObjKey(obj);
  
  _cObjKey = sObjKey;

  std::cout << "Notify Event to RIMS class " << std::endl;
  (*this).notifyEvent(*this);
  std::cout << "End notify Event" << std::endl;

  if( _result) for(int i=0;i<12;i++) pose[i] = _objPose[i];
  
  return _result;
  
}

CORBA::Boolean RIMSServiceSVC_impl::getNewObjectPose(const char* obj, RIMSService::ObjectPose pose)
{
  // set recognition mode 
  _mode = "getNew";
  notGetResult();

  while(_objInfoFlag){
    //usleep(10);
  }
  
  //set key
  std::string sObjKey(obj);
  
  _cObjKey = sObjKey;

  std::cout << "Notify Event to RIMS class " << std::endl;
  (*this).notifyEvent(*this);
  std::cout << "End notify Event" << std::endl;

  if( _result) for(int i=0;i<12;i++) pose[i] = _objPose[i];
  
  return _result;
}

// End of example implementational code



