// -*-C++-*-
/*!
 * @file  RIMSServiceSVC_impl.h
 * @brief Service implementation header of RIMSService.idl
 *
 */

#include "RIMSServiceSkel.h"

#ifndef RIMSSERVICESVC_IMPL_H
#define RIMSSERVICESVC_IMPL_H
 
#include <string>
//#include "ObjectInformationManager.h"
#include "MultiCastEventListener.h"


using namespace ALTH;

/*!
 * @class RIMSServiceSVC_impl
 * Example class implementing IDL interface RIMSService
 */
class RIMSServiceSVC_impl
 : public virtual POA_RIMSService,
   public virtual PortableServer::RefCountServantBase,
   public EventSource<RIMSServiceSVC_impl>
{
 private:
   // Make sure all instances are built on the heap by making the
   // destructor non-public
   //virtual ~RIMSServiceSVC_impl();

 public:
  /*!
   * @brief standard constructor
   */
   RIMSServiceSVC_impl();
  /*!
   * @brief destructor
   */
   virtual ~RIMSServiceSVC_impl();

   // attributes and operations
  CORBA::Boolean getObjectPose (const char* obj, RIMSService::ObjectPose pose);
  CORBA::Boolean getNewObjectPose(const char* obj, RIMSService::ObjectPose pose);

private:
  // current mode 
  std::string _mode;
  // current search key
  std::string _cObjKey;
  double _objPose[12];

public:
  inline std::string getMode()const{ return _mode;};
  inline std::string getCurrentObjKey()const{return _cObjKey;}
  inline void setObjectPose( double  objPose[12]){
    for(int i=0;i<12;i++) _objPose[i] = objPose[i];
  }
private:
  // getObjectPose result 
  bool _result;
  // service port lock flag
  bool _objInfoFlag;
public:
  inline void getResult(){_result = true;}
  inline void notGetResult(){_result = false;}
  inline void lockObjInfoService(){_objInfoFlag = true;}
  inline void unlockObjInfoService(){_objInfoFlag = false;}
  
// private:
//   double _tm;
// public:
//   inline void setTimeOutValue(double tm){ _tm=tm; }



};



#endif // RIMSSERVICESVC_IMPL_H


