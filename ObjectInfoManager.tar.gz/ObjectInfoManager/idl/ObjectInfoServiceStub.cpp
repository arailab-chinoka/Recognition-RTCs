// -*- C++ -*-
/*!
 *
 * THIS FILE IS GENERATED AUTOMATICALLY!! DO NOT EDIT!!
 *
 * @file ObjectInfoServiceStub.cpp 
 * @brief ObjectInfoService client stub wrapper code
 * @date Tue Oct  4 22:20:24 2011 
 *
 */

#include "ObjectInfoServiceStub.h"

#if   defined ORB_IS_TAO
#  include "ObjectInfoServiceC.cpp"
#elif defined ORB_IS_OMNIORB
#  include "ObjectInfoServiceSK.cc"
#  include "ObjectInfoServiceDynSK.cc"
#elif defined ORB_IS_MICO
#  include "ObjectInfoService.cc"
#elif defined ORB_IS_ORBIT2
#  include "ObjectInfoService-cpp-stubs.cc"
#else
#  error "NO ORB defined"
#endif

// end of ObjectInfoServiceStub.cpp
