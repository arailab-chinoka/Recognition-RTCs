
/**
* RIMSServicePOA.java .
* IDL-to-Java コンパイラ (ポータブル), バージョン "3.1" で生成
* 生成元: RIMSService.idl
* 2011年10月17日 16時12分13秒 JST
*/


//**************************************************
public abstract class RIMSServicePOA extends org.omg.PortableServer.Servant
 implements RIMSServiceOperations, org.omg.CORBA.portable.InvokeHandler
{

  // Constructors

  private static java.util.Hashtable _methods = new java.util.Hashtable ();
  static
  {
    _methods.put ("getObjectPose", new java.lang.Integer (0));
    _methods.put ("getNewObjectPose", new java.lang.Integer (1));
  }

  public org.omg.CORBA.portable.OutputStream _invoke (String $method,
                                org.omg.CORBA.portable.InputStream in,
                                org.omg.CORBA.portable.ResponseHandler $rh)
  {
    org.omg.CORBA.portable.OutputStream out = null;
    java.lang.Integer __method = (java.lang.Integer)_methods.get ($method);
    if (__method == null)
      throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);

    switch (__method.intValue ())
    {

  //          false: fail to getting object pose
       case 0:  // RIMSService/getObjectPose
       {
         String obj = in.read_string ();
         RIMSServicePackage.ObjectPoseHolder pose = new RIMSServicePackage.ObjectPoseHolder ();
         boolean $result = false;
         $result = this.getObjectPose (obj, pose);
         out = $rh.createReply();
         out.write_boolean ($result);
         RIMSServicePackage.ObjectPoseHelper.write (out, pose.value);
         break;
       }


  //          false: fail to getting object pose
       case 1:  // RIMSService/getNewObjectPose
       {
         String obj = in.read_string ();
         RIMSServicePackage.ObjectPoseHolder pose = new RIMSServicePackage.ObjectPoseHolder ();
         boolean $result = false;
         $result = this.getNewObjectPose (obj, pose);
         out = $rh.createReply();
         out.write_boolean ($result);
         RIMSServicePackage.ObjectPoseHelper.write (out, pose.value);
         break;
       }

       default:
         throw new org.omg.CORBA.BAD_OPERATION (0, org.omg.CORBA.CompletionStatus.COMPLETED_MAYBE);
    }

    return out;
  } // _invoke

  // Type-specific CORBA::Object operations
  private static String[] __ids = {
    "IDL:RIMSService:1.0"};

  public String[] _all_interfaces (org.omg.PortableServer.POA poa, byte[] objectId)
  {
    return (String[])__ids.clone ();
  }

  public RIMSService _this() 
  {
    return RIMSServiceHelper.narrow(
    super._this_object());
  }

  public RIMSService _this(org.omg.CORBA.ORB orb) 
  {
    return RIMSServiceHelper.narrow(
    super._this_object(orb));
  }


} // class RIMSServicePOA
