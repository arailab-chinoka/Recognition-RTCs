
/**
* RIMSServiceOperations.java .
* IDL-to-Java コンパイラ (ポータブル), バージョン "3.1" で生成
* 生成元: RIMSService.idl
* 2011年10月17日 16時12分13秒 JST
*/


//**************************************************
public interface RIMSServiceOperations 
{

  //          false: fail to getting object pose
  boolean getObjectPose (String obj, RIMSServicePackage.ObjectPoseHolder pose);

  //          false: fail to getting object pose
  boolean getNewObjectPose (String obj, RIMSServicePackage.ObjectPoseHolder pose);
} // interface RIMSServiceOperations
