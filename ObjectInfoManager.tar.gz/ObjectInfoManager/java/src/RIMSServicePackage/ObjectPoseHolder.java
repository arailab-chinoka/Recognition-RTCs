package RIMSServicePackage;


/**
* RIMSServicePackage/ObjectPoseHolder.java .
* IDL-to-Java コンパイラ (ポータブル), バージョン "3.1" で生成
* 生成元: RIMSService.idl
* 2011年10月17日 16時12分13秒 JST
*/

public final class ObjectPoseHolder implements org.omg.CORBA.portable.Streamable
{
  public double value[] = null;

  public ObjectPoseHolder ()
  {
  }

  public ObjectPoseHolder (double[] initialValue)
  {
    value = initialValue;
  }

  public void _read (org.omg.CORBA.portable.InputStream i)
  {
    value = RIMSServicePackage.ObjectPoseHelper.read (i);
  }

  public void _write (org.omg.CORBA.portable.OutputStream o)
  {
    RIMSServicePackage.ObjectPoseHelper.write (o, value);
  }

  public org.omg.CORBA.TypeCode _type ()
  {
    return RIMSServicePackage.ObjectPoseHelper.type ();
  }

}
