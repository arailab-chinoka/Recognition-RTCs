
/**
* RIMSService.java .
* IDL-to-Java コンパイラ (ポータブル), バージョン "3.1" で生成
* 生成元: RIMSService.idl
* 2011年10月17日 16時12分13秒 JST
*/


//**************************************************
public interface RIMSService extends RIMSServiceOperations, org.omg.CORBA.Object, org.omg.CORBA.portable.IDLEntity 
{
} // interface RIMSService
