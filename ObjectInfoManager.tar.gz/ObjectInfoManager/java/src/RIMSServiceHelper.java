
/**
* RIMSServiceHelper.java .
* IDL-to-Java コンパイラ (ポータブル), バージョン "3.1" で生成
* 生成元: RIMSService.idl
* 2011年10月17日 16時12分13秒 JST
*/


//**************************************************
abstract public class RIMSServiceHelper
{
  private static String  _id = "IDL:RIMSService:1.0";

  public static void insert (org.omg.CORBA.Any a, RIMSService that)
  {
    org.omg.CORBA.portable.OutputStream out = a.create_output_stream ();
    a.type (type ());
    write (out, that);
    a.read_value (out.create_input_stream (), type ());
  }

  public static RIMSService extract (org.omg.CORBA.Any a)
  {
    return read (a.create_input_stream ());
  }

  private static org.omg.CORBA.TypeCode __typeCode = null;
  synchronized public static org.omg.CORBA.TypeCode type ()
  {
    if (__typeCode == null)
    {
      __typeCode = org.omg.CORBA.ORB.init ().create_interface_tc (RIMSServiceHelper.id (), "RIMSService");
    }
    return __typeCode;
  }

  public static String id ()
  {
    return _id;
  }

  public static RIMSService read (org.omg.CORBA.portable.InputStream istream)
  {
    return narrow (istream.read_Object (_RIMSServiceStub.class));
  }

  public static void write (org.omg.CORBA.portable.OutputStream ostream, RIMSService value)
  {
    ostream.write_Object ((org.omg.CORBA.Object) value);
  }

  public static RIMSService narrow (org.omg.CORBA.Object obj)
  {
    if (obj == null)
      return null;
    else if (obj instanceof RIMSService)
      return (RIMSService)obj;
    else if (!obj._is_a (id ()))
      throw new org.omg.CORBA.BAD_PARAM ();
    else
    {
      org.omg.CORBA.portable.Delegate delegate = ((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate ();
      _RIMSServiceStub stub = new _RIMSServiceStub ();
      stub._set_delegate(delegate);
      return stub;
    }
  }

  public static RIMSService unchecked_narrow (org.omg.CORBA.Object obj)
  {
    if (obj == null)
      return null;
    else if (obj instanceof RIMSService)
      return (RIMSService)obj;
    else
    {
      org.omg.CORBA.portable.Delegate delegate = ((org.omg.CORBA.portable.ObjectImpl)obj)._get_delegate ();
      _RIMSServiceStub stub = new _RIMSServiceStub ();
      stub._set_delegate(delegate);
      return stub;
    }
  }

}
